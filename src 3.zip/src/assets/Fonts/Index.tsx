type FONTTYPE = {
    [key: string]: string;
  };
  export const FONTS: FONTTYPE = {
    bold: 'FontsFree-Net-SF-UI-Display-Bold',
    // regular: 'FontsFree-Net-SF-UI-Display-Regular',
    medium: 'FontsFree-Net-SF-UI-Display-Medium',
    semibold: 'FontsFree-Net-SF-UI-Display-SemiBold',
    light: 'FontsFree-Net-SF-UI-Display-Light',
  
  }