import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import React from 'react';
import { COLORS, FONTS, VECTOR_ICONS } from '../../assets/Theme';
import GoogleSvg from "../../Components/SvgComponent/Login/GoogleSvg"


const WholeButton = (props: any) => {
  return (
    <TouchableOpacity style={[styles.WholeButtonStyle, props.styles,]}>

      <TouchableOpacity
        disabled={props.disabled}
        onPress={props.Action}
        style={{ flexDirection: props?.Facebook || props?.Google ? "row" : "", alignItems: "center", justifyContent: "center", textAlign: "Center" }}
      >{
          props?.Facebook &&

          <VECTOR_ICONS.EvilIcons name={"sc-facebook"} size={45} color={"white"} style={{ marginBottom: "1%" }} />
        }
        {
          props?.Google &&
          <View>
            <GoogleSvg />
          </View>

        }
        <Text style={[styles.buttonText, { color: props?.Google ? "#262626" : COLORS.WHITE, fontWeight: Platform.OS === 'ios' ? '600' : '400' }, props.headingstyle]}>{props.Label}</Text>

      </TouchableOpacity>
    </TouchableOpacity>
  );
};

export default WholeButton;

const styles = StyleSheet.create({

  buttonText: {
    fontSize: 17,

    textAlign: 'center',
    fontFamily: FONTS.bold,
    margin: 7,
  },
  WholeButtonStyle: {
    width: '90%',
    alignSelf: 'center',
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: COLORS.BACKGROUNDBTNCOLOR,

  },
});
