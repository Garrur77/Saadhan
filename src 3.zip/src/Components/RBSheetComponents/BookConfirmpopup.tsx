import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  FlatList,
  TextInput,
  ImageBackground,
  Image,
  Linking,
  Platform,
  ActivityIndicator
} from "react-native";
import React, { useEffect, useRef, useState } from "react";
import { WIDTH, HEIGHT } from "../../Components/Helpers/Dimentions";
import { COLORS, FONTS, VECTOR_ICONS, IMAGEPATH } from "../../assets/Theme";
import WholeButton from "../Wholebutton/Wholebutton";
import ModalComponent from "../ModalComponent/ModalComponent";
import MapBackground from "../GlobalBackground/MapBackground";
import RBSheet from "react-native-raw-bottom-sheet";
import { useFocusEffect, useIsFocused, useNavigation } from '@react-navigation/native';
import Map1 from "../SvgComponent/Location/Map1";
import Message from "../SvgComponent/CancelRide/Message";
import Call from "../SvgComponent/CancelRide/Call";
import CarSvg from '../SvgComponent/CarRide/CarSvg';
import { useSelector } from "react-redux";
import { RootState } from "../../ReduxConfig/Store";
import io from "socket.io-client";
import { SOCKET_URL } from "../../ApiConfig/Endpoints";
import SpiningLoader from "../../assets/SpiningLoader";
import RateModalComponent from "../ModalComponent/RateModalComponent";
import socketServcies from "../../Utils/SocketService";

const platformType = Platform.OS;
const BookConfirmpopup = (props: any) => {
  const { vehicleDetails, closedRbSheet3Suceess, Ridetails,acceptOTP,onlineStatus } = props;
  const [loading, setLoading] = useState(true);
  const [Loader, setLoader] = useState(false);
  const [modalVisibleRate, setModalVisibleRate] = useState(false)
  const Data = useSelector(
    (state: RootState) => state.userDetails?.profileData
);
  const [initialUrl, setInitialUrl] = useState(`https://maps.apple.com/?saddr=28.5815,77.3163&daddr=28.5696,77.3128`); console.log("loading----00", loading)
  // const Ridetails = useSelector(
  //   (state: RootState) => state?.rideDetailsSelector?.RideDetails
  // );
  console.log("acceptOTP-----acceptOTP", acceptOTP);


  const navigation = useNavigation()

  useEffect(() => {
    if (Ridetails) {
      console.log("reide--deatils function calling")
      setLoading(false);
      setLoader(false)
    }
  }, [Ridetails]);

  console.log("vehicleDetails****", vehicleDetails);


  // const openCallLog = () => {
  //   if (Platform.OS === "android") {
  //     Linking.openURL("tel:");
  //   } else if (Platform.OS === "ios") {
  //     Linking.openURL("telprompt:");
  //   }
  // };
  const phoneNumber = Ridetails?.driverDetails?.driverPhone; // Replace with the desired phone number

  const openCallLog = () => {
    const phoneNumberWithPrefix = `tel:${phoneNumber}`;

    Linking.openURL(phoneNumberWithPrefix)
      .catch((err) => console.error('An error occurred', err));
  };
  const OpenDirection = () => {
    const iniatialRoute = `https://maps.apple.com/?saddr=${Ridetails?.pickupLocation?.latitude},${Ridetails?.pickupLocation?.longitude}&daddr=${Ridetails?.destinationLocation?.latitude},${Ridetails?.destinationLocation?.longitude}`;

    Linking.openURL(iniatialRoute)
      .catch((err) => console.error('An error occurred', err));
  };
  const bottomSheetRef = useRef(null);
  const Isfocus = useIsFocused();


  useFocusEffect(
    React.useCallback(() => {
      if (bottomSheetRef.current) {
        bottomSheetRef.current.open();
      }

    }, [bottomSheetRef])
  );
  const sheetHeight = Platform.OS === 'ios' ? 425 : 430;

  const endRide = () => {
    // const rideId = Ridetails?.rideId;
    socketServcies?.on("rideEnded", (response) => {
      console.log("tttetetetetetetete1",response)
      if (response?.ridedata?.status === "completed" && response?.ridedata?.riderId?._id === Data?._id) {
        setTimeout(() => {
          setModalVisibleRate(true);
        }, 300)
        // setModalVisibleRate(true)
        console.log("setModalVisibleRate")
    }

      console.log("new ride status", response);
    });
  };

  




  useEffect(() => {
    endRide()
  }, [Isfocus])


  return (
    <SafeAreaView>
      <View style={styles.mainView}>
        <View >
        
        {
    (Ridetails && Object.keys(Ridetails).length === 0) || (Ridetails?.riderDetails?.riderId !== Data?._id) ? (
      <View style={{ flexDirection: 'column', justifyContent: 'center', alignItems: 'center', width: WIDTH * 0.9, marginVertical: HEIGHT * 0.15 }}>
        <ActivityIndicator size='large' color={COLORS.YOUR_LOADER_COLOR} />
        <Text style={{ color: '#000', fontSize: 14, paddingTop: 15 }}>Looking for your driver</Text>
      </View>
    ) : (
      
            <>
              <View style={{ flexDirection: 'row', alignContent: 'center', width: WIDTH * 0.9, marginVertical: 20 }}>

                <Image
                  source={
                    Ridetails?.driverDetails?.driverImage
                      ? { uri: Ridetails?.driverDetails?.driverImage }
                      : IMAGEPATH.Man2
                  }
                  style={{ width: 50, height: 50, borderRadius: 100 }}


                />

                <View style={{ width: WIDTH * 0.4, marginLeft: "4%" }}>
                  <Text style={styles.head}>{Ridetails?.driverDetails?.driverName ?? ""}</Text>
                  {
                    Ridetails?.driverDetails?.rating ? <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: '3%' }}>
                      <Image source={IMAGEPATH.star}
                      />
                      <Text style={{ color: '#C8C7CC', fontSize: 17, fontFamily: FONTS.semibold, marginLeft: '3%' }}>{Ridetails?.driverDetails?.rating}</Text>
                    </View> : null
                  }

                </View>
                <View style={{ flexDirection: 'row', width: WIDTH * 0.35, justifyContent:acceptOTP ?  'space-between' : 'flex-end',  }}>
                 {acceptOTP && 
                  <TouchableOpacity
                    onPress={OpenDirection}
                    style={{
                      width: 40, height: 40, borderRadius: 100,marginRight:acceptOTP ? 5 : 0, alignItems: "center", justifyContent: 'center', borderWidth: 0.2
                    }}>
                    <VECTOR_ICONS.MaterialCommunityIcons
                      name="directions"
                      size={30}
                      color={""}
                      style={{}}
                    />

                  </TouchableOpacity>
                  } 
                  <TouchableOpacity
                    onPress={props.Action}
                    style={{
                      backgroundColor: '#4252FF',marginRight:acceptOTP ? 5 : 5, width: 40, height: 40, borderRadius: 100, alignItems: "center", justifyContent: 'center', borderWidth: 0.2
                    }}>

                    <Message />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={openCallLog} style={{
                    backgroundColor: '#FF5500', width: 40, height: 40, borderRadius: 100, alignItems: "center", justifyContent: 'center', borderWidth: 0.2
                  }}>
                    <Call />
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.line1}></View>
              <View style={styles.topview}>
                <View style={{ marginTop: platformType === 'ios' ? "10%" : "13%", marginLeft: '4%' }}>
                  <Map1 />
                </View>
                <View>
                  <View style={{ flexDirection: 'row' }}>
                    <View>
                      <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: WIDTH * 0.78, paddingVertical: 6 }}>
                        <Text style={[styles.pickup, { marginTop: '4%' }]}>Pick Up</Text>

                        {
                          Ridetails?.otp ?
                            <Text style={[styles.pickup, { marginTop: '4%', fontWeight: "800", fontSize: 20, color:'Violet' }]}>{Ridetails?.otp}</Text> : null
                        }

                      </View>

                      <Text
                        numberOfLines={2}
                        style={{
                          color: "#242E42",
                          fontSize: 17,
                          fontFamily: FONTS.semibold,
                          marginLeft: "5%",
                          width: WIDTH * 0.62,
                          marginTop: "1%"
                        }}>{Ridetails?.pickupAddress ?? ""}</Text>
                    </View>

                  </View>
                  <View style={[styles.line, { marginLeft: "1%", width: WIDTH * 0.8, marginTop: '2.5%' }]}></View>
                  <View style={{ marginTop: '2%' }}>
                    <View>
                      <Text style={styles.pickup}>Destination</Text>
                      <Text
                        numberOfLines={2}
                        style={{
                          color: "#242E42",
                          fontSize: 17,
                          fontFamily: FONTS.semibold,
                          marginLeft: "5%",
                          width: WIDTH * 0.62,
                          marginTop: "1%"
                        }}>{Ridetails?.destinationAddress ?? ""}</Text>
                    </View>

                  </View>
                </View>
              </View>
              <View style={[styles.line, { marginTop: '5%' }]}></View>
              <View style={{ flexDirection: 'row', }}>
                <>
                  <View style={{ marginTop: '5%', }}>
                    <CarSvg />
                  </View>
                  <View>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: WIDTH * 0.64, marginLeft: '10%', marginTop: '5%' }}>
                      <Text style={{ color: '#C8C7CC', fontSize: 15, fontFamily: FONTS.bold }}>DISTANCE</Text>
                      <Text style={{ color: '#C8C7CC', fontSize: 15, fontFamily: FONTS.bold }}>TIME</Text>
                      <Text style={{ color: '#C8C7CC', fontSize: 15, fontFamily: FONTS.bold }}>PRICE</Text>
                    </View>
                    <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: WIDTH * 0.64, marginLeft: '13%', marginTop: '2%' }}>
                      <Text style={{ color: '#242E42', fontSize: 15, fontFamily: FONTS.bold, fontWeight: "600" }}>
                        {Ridetails?.distance}
                        {/* {parseFloat(Ridetails?.distance).toFixed(2)} Km */}
                      </Text>
                      <Text style={{ color: '#242E42', fontSize: 15, fontFamily: FONTS.bold, fontWeight: "600" }}>{Ridetails?.estimatedTimeInMinutes ?? "0.00"}</Text>
                      <Text style={{ color: '#242E42', fontSize: 15, fontFamily: FONTS.bold, fontWeight: "600" }}>${parseFloat(Ridetails?.fareAmount).toFixed(2)}</Text>
                    </View>

                  </View>
                </>

              </View>
            </>
         ) }
          {!acceptOTP && 
            <View style={{ marginTop:loading ? '5%' : '13%', marginBottom:loading ? '12%' : "9%" }}>
              <WholeButton Label={'Cancel Request'} styles={{ backgroundColor: "#242E42", paddingVertical:6 }} Action={props?.Action1} />
            </View>
          } 

     {onlineStatus ==="ongoing" && 
            <View style={{ marginTop:loading ? '5%' : '13%', marginBottom:loading ? '12%' : "9%" }}>
              <WholeButton Label={'Cancel Request'} styles={{ backgroundColor: "#242E42", paddingVertical:6 }} Action={props?.Action1} />
            </View>
          } 



        </View>

        {/* </RBSheet> */}

      </View>

      <RateModalComponent
                            setModalVisible={setModalVisibleRate}
                            modalVisible={modalVisibleRate}
                            rate={'Rate Your Driver'}
                            head={'Ride Finished'}
                            Message={'Cash Paid - $24.89'}
                            img
                            Button="Submit"
                            Action2={() => {
                                setModalVisibleRate(false);
                                props.navigation.navigate('BottomTabBar')
                            }}
                            source={IMAGEPATH.success}
                            imgstyle={{ width: 48, height: 48, resizeMode: 'cover' }}
                            modalstyle={{
                                width: WIDTH * 0.75,
                            }}
                            msgstyle={{ fontSize: 16, color: '#242E42' }}
                        />


      {/* </MapBackground> */}

    </SafeAreaView>
  )
}

export default BookConfirmpopup

const styles = StyleSheet.create({
  line1: {
    backgroundColor: "#ECECEC",
    width: WIDTH * 0.9,
    height: 3,
    // marginTop: "5%",
    alignSelf: "center",
  },
  head: {
    fontSize: 17,
    fontFamily: FONTS.bold,
    // alignSelf: "center",
    color: "#242E42",
  },
  pickup: {
    color: "#242E42",
    fontSize: 14,
    fontFamily: FONTS.bold,
    marginLeft: "5%",
  },
  line: {
    backgroundColor: "#ECECEC",

    width: WIDTH * 0.9,
    height: 1,
    // marginTop: "5%",
    alignSelf: "center",
  },
  topview: {
    flexDirection: 'row',
    width: WIDTH * 0.9,
    justifyContent: 'space-between'
  },
  firstView1: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    backgroundColor: COLORS.WHITE,
  },
  mainView: { width: WIDTH * 0.9, alignSelf: "center" },
  backIcon: {
    backgroundColor: "rgba(0, 0, 0, 0.1)",
    width: 46,
    height: 46,
    borderRadius: 23,
    marginVertical: "5%",
    alignItems: "center",
    justifyContent: "center"
  },
})