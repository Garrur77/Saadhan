
import React, { useEffect } from 'react'
import { SafeAreaView, ScrollView, StyleSheet, Text, View, Image, Platform, StatusBar } from 'react-native'
import Header from '../../Components/HeaderComponent/Header'

import { FONTS, VECTOR_ICONS, COLORS, IMAGEPATH } from '../../assets/Theme'
import { WIDTH, HEIGHT } from '../../Components/Helpers/Dimentions'
import Rupees from '../../Components/SvgComponent/History/Rupees'
import moment from 'moment'
// import Geolocation from 'react-native-geolocation-service';
// import { request, PERMISSIONS } from 'react-native-permissions';
const platformType = Platform.OS;
const Receipt = (props: any) => {

    const data = props?.route?.params?.data;
    console.log('recepitDATAAAAAAAA', data)

    return (
        <>
            <SafeAreaView style={{ backgroundColor: COLORS.BACKGROUNDBTNCOLOR }}></SafeAreaView>
            <StatusBar
                backgroundColor={COLORS.BACKGROUNDBTNCOLOR}
                barStyle={"dark-content"}
            />
            <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.WHITE }}>

                <View>
                    <Header navigation={props?.navigation} Heading={'Receipt Of Your Ride'}
                        HeaderStyle={{ marginLeft: '14%' }}
                        reset={true}
                        ToScreen={"BottomTabBar"}
                     />

                    <View style={styles.mainview}>
                        <View style={{ marginLeft: "4%", }}>
                            <Text style={styles.date}>{moment(data?.createdAt).format("LL")}</Text>
                            <Text style={styles.thankstext}>Thanks For {"\n"} riding, {data?.driverId?.firstName}</Text>
                        </View>
                        <View style={{ justifyContent: 'flex-end' }}>
                            <Image source={IMAGEPATH.Car} />
                        </View>
                    </View>

                    <View style={styles.totalview}>
                        <Text style={styles.totaltext}>Total</Text>
                        <Text style={[styles.totaltext, { color: "rgba(36, 46, 66, 1)" }]}>
                        ${parseFloat(data?.fareAmount).toFixed(2)}
                        </Text>
                    </View>

                    <View style={styles.lineStyle}></View>
                    <View style={styles.totalview}>
                        <Text style={styles.ridertext}>Rider ID :</Text>
                        <Text style={[styles.ridertext1, { fontFamily: FONTS.medium, fontWeight: Platform.OS === 'ios' ? '500' : '400' }]}>{data?.riderId}</Text>
                    </View>
                    <View style={[styles.totalview, { marginVertical: 1 }]}>
                        <Text style={styles.ridertext}>Vehicle Type :</Text>
                        <Text style={[styles.ridertext1, { fontFamily: FONTS.medium, fontWeight: Platform.OS === 'ios' ? '500' : '400', textTransform: "capitalize" }]}>{data?.vehicleType}</Text>
                    </View>
                    <View style={[styles.lineStyle, { marginVertical: "4%" }]}></View>

                    <View style={styles.totalview}>
                        <Text style={styles.ridertext}>Basic Fare :</Text>
                        <Text style={[styles.ridertext1, { fontFamily: FONTS.medium, fontWeight: Platform.OS === 'ios' ? '500' : '400' }]}>{data?.basicfare ?? 0.00}</Text>
                    </View>
                    <View style={[styles.totalview, { marginVertical: 1 }]}>
                        <Text style={styles.ridertext}>Platform fee :</Text>
                        <Text style={[styles.ridertext1, { fontFamily: FONTS.medium, fontWeight: Platform.OS === 'ios' ? '500' : '400' }]}>{data?.platformFee ?? 0.00}</Text>
                    </View>
                    <View style={[styles.lineStyle, { marginTop: "4%" }]}></View>
                    <View style={styles.lastview}>
                        <Text style={styles.paymenttext}>Payment Options</Text>
                        <View style={{ flexDirection: "row", marginVertical: "7%" }}>
                            <Rupees />
                            <Text style={[styles.ridertext1, { fontSize: 15, fontFamily: FONTS.medium, marginHorizontal: "3%" }]}>{data?.paymentMethod}</Text>
                        </View>
                    </View>
                </View>

            </SafeAreaView>
            <SafeAreaView style={{ backgroundColor: "#fff" }}></SafeAreaView>
        </>
    )
}

export default Receipt

const styles = StyleSheet.create({
    mainview: {
        flexDirection: "row", marginVertical: "10%", justifyContent: 'space-between'
    },
    date: { fontFamily: FONTS.medium, fontSize: 14, color: "rgba(38, 38, 38, 1)", fontWeight: Platform.OS === 'ios' ? '500' : '400' },
    thankstext: { fontFamily: FONTS.bold, fontSize: 26, color: "rgba(38, 38, 38, 1)", marginVertical: "5%", fontWeight: Platform.OS === 'ios' ? '600' : '400' },
    lineStyle: {
        borderBottomColor: "rgba(224, 224, 224, 1)",
        borderBottomWidth: 2,
        width: WIDTH * 0.9,
        alignSelf: "center"
    },
    totalview: { flexDirection: "row", width: WIDTH * 0.9, alignSelf: "center", justifyContent: "space-between", marginVertical: "3%" },
    totaltext: {
        fontFamily: FONTS.bold,
        fontSize: 18,
        color: "rgba(38, 38, 38, 1)",
        fontWeight: Platform.OS === 'ios' ? '600' : '400'
    },
    ridertext: {
        fontFamily: FONTS.bold,
        fontSize: 16,
        color: "rgba(36, 46, 66, 1)",
        fontWeight: Platform.OS === 'ios' ? '600' : '400'
    },
    ridertext1: {
        fontFamily: FONTS.bold,
        fontSize: 15,
        color: "rgba(36, 46, 66, 1)",
        fontWeight: Platform.OS === 'ios' ? '600' : '400'
    },
    paymenttext: {
        fontFamily: FONTS.medium,
        fontSize: 12,
        color: "rgba(138, 138, 143, 1)"
    },
    lastview: {
        width: WIDTH * 0.9,
        alignSelf: "center",
        marginVertical: "5%"

    },


})