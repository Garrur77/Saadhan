import {
  View,
  Text,
  SafeAreaView,
  StyleSheet,
  ScrollView,
  FlatList,
  StatusBar,
  Platform,
} from "react-native";
import React, { useEffect, useState } from "react";
import { COLORS, FONTS } from "../../assets/Theme";
import { WIDTH } from "../../Components/Helpers/Dimentions";
import Header from "../../Components/HeaderComponent/Header";
import { callGetApi } from "../../ApiConfig/ApiCall";
import { fetchStaticContent } from "../../ApiConfig/Endpoints";
import { useIsFocused } from "@react-navigation/native";
import HTMLView from "react-native-htmlview";


const termsandconditions = (props: any) => {
  const [Loader, setLoader] = useState(false);
  const [data, setData] = useState('')

  console.log("adfsadgfasdf", data);
  const isfocus = useIsFocused();


  //API for terms and condition
  const TermsConditon = async () => {
    console.log("hiiiiiiiiiiiii");
    setLoader(true);
    try {
      const SucessDisplay = true;

      const { response, error, loading } = await callGetApi(
        fetchStaticContent,

        SucessDisplay
      );
      setLoader(loading);
      console.log('resss', response)
      if (error) {
        console.error("API Error:", error);
      } else {
        if (response?.responceCode === 200) {
          const termsData = response?.data?.filter((item) => item?.type === 'terms')
          console.log('vasghbvadhbvsa', { termsData })
          setData(termsData)
          setLoader(false);
        }
      }


    } catch (error: any) {
      console.error("Error during register:", error, error.response);
    }
  };
  console.log('final data', data[0]?.title)

  useEffect(() => {
    TermsConditon()
  }, [isfocus])

  return (
    <>
      <SafeAreaView
        style={{ backgroundColor: COLORS.BACKGROUNDBTNCOLOR }}
      ></SafeAreaView>
      <StatusBar
        backgroundColor={COLORS.BACKGROUNDBTNCOLOR}
        barStyle={"dark-content"}
      />
      <SafeAreaView style={{ backgroundColor: COLORS.WHITE, flex: 1 }}>
        <Header navigation={props?.navigation} Heading={'Terms & Conditions'} HeaderStyle={{ marginLeft: '10%' }}  />

        <ScrollView showsVerticalScrollIndicator={false}>
          <View style={{paddingVertical:20, paddingHorizontal:15}}>
          <HTMLView
                value={data[0]?.description}
                stylesheet={styles}
              />
          </View>
          {/* <FlatList
            data={data}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={() => (
              <View style={style.emptyListComponent}>
                <Text style={style.emptyListText}>No data found</Text>
              </View>
            )}
            renderItem={(item: any) => {
              return (
                <View style={style.mainView}>
                  <Text style={style.textStyle}>{data[0]?.title}</Text>
                  <View style={{ flexDirection: "row" }}>
                    {item?.item?.num && (
                      <Text style={style.textStyle1}>{data[0].description}</Text>
                    )}
                    <Text style={style.textStyle1}>{data[0].description}</Text>
                  </View>
                  <View style={{ flexDirection: "row" }}>
                    {item?.item?.num2 && (
                      <Text style={style.textStyle1}>{item?.item?.num2}</Text>
                    )}
                    <Text style={style.textStyle1}>{item?.item?.text1}</Text>
                  </View>
                  {item?.item?.num3 && (
                    <View style={{ flexDirection: "row" }}>
                      <Text style={style.textStyle1}>{item?.item?.num3}</Text>

                      <Text style={style.textStyle1}>{item?.item?.text1}</Text>
                    </View>
                  )}
                </View>
              );
            }}
          /> */}
        </ScrollView>
      </SafeAreaView>
      <SafeAreaView style={{ backgroundColor: "#fff" }}></SafeAreaView>
    </>
  );
};

export default termsandconditions;
const styles = StyleSheet.create({
  mainView: {
    width: WIDTH * 0.9,
    alignSelf: "center",
    paddingVertical: "3.5%",
  },
  text: {
    fontSize: 14,
    color: "#242E42",
    marginTop: Platform.OS === "ios" ? 0 : 10,
    // fontFamily: "AirbnbCerealMedium",
  },
  textStyle: {
    fontSize: 16,
    fontFamily: FONTS.bold,
    color: COLORS.BuleText,
    paddingVertical: "3.5%",
  },
  p: {
    color: '#242E42', // make links coloured pink
    lineHeight:20,
    fontSize:15
  },
  textStyle1: {
    fontSize: 12,
    fontFamily: FONTS.light,
    color: "rgba(0, 0, 0, 0.6)",
    paddingVertical: "2%",
    lineHeight: 20,
  },
  emptyListComponent: {
    flex: 1,
    backgroundColor: '#ffff',
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    padding: 20,
  },
  emptyListText: {
    fontSize: 16,
    color: '#555', // Customize the color
  },
});
