import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  TextInput,
  StatusBar,
} from "react-native";
import React, { useState } from "react";
import Header from "../../Components/HeaderComponent/Header";
import InputFiled from "../../Components/ValidationsConfig/InputField";
import {
  ValidateEmail,
  ValidateFullname,
  ValidateMobileNumber,
  ValidationMessgaeBox,
} from "../../Components/ValidationsConfig/Validations";
import { COLORS, FONTS, IMAGEPATH } from "../../assets/Theme";
import { HEIGHT, WIDTH } from "../../Components/Helpers/Dimentions";
import WholeButton from "../../Components/Wholebutton/Wholebutton";
import ModalComponent from "../../Components/ModalComponent/ModalComponent";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { submitQuery } from "../../ApiConfig/Endpoints";
import { callPostApi } from "../../ApiConfig/ApiCall";
import SpiningLoader from "../../assets/SpiningLoader";


const SubmitYourQuery = (props: any) => {
  const [Email, setEmail] = useState("");
  const [Name, setName] = useState("");
  const [Nameerror, setNameerror] = useState("");
  const [EmailError, setEmailError] = useState("");
  const [phone, setPhone] = useState("");
  const [phoneError, setPhoneError] = useState("");
  const [msg, setMsg] = useState("");
  const [Loader, setLoader] = useState(false);
  const [msgError, setmsgError] = useState("");
  const [ShowError, setShowError] = useState({
    emailError: false,
    fullNmError: false,
    phoneerror: false,
    messageError: false,
  });

  //submitQuery api 
  const SubmitQuery = async () => {
    setLoader(true);
    try {
      const postData = {
        name: Name,
        email: Email,
        phone: phone,
        message: msg
      }
      const SucessDisplay = true;
      const { response, error, loading } = await callPostApi(
        submitQuery,
        postData,
        SucessDisplay
      );
      setLoader(loading);
      console.log('querttt', response)
      if (error) {
        console.error("API Error:", error);
        setLoader(false);
      }
      if (response?.responceCode === 200) {
        setLoader(false);
        props.navigation.navigate("BottomTabBar");
      }
    } catch (error) {
      console.log('errordfsdfsdfs', error)
      setLoader(false);
    }
  }


  const Submit = () => {
    let emailErr = ValidateEmail(Email);
    let nameErr = ValidateFullname(Name);
    let phoneErr = ValidateMobileNumber(phone);
    let MessageError = ValidationMessgaeBox(msg);
    if (
      emailErr === "" &&
      nameErr === "" &&
      phoneErr === "" &&
      MessageError === ""
    ) {

      SubmitQuery()
    } else {
      setEmailError(emailErr);
      setNameerror(nameErr);
      setPhoneError(phoneErr);
      setmsgError(MessageError);
      setShowError({
        emailError: true,
        fullNmError: true,
        phoneerror: true,
        messageError: true,
      });
    }
  };


  return (
    <>
      <SafeAreaView
        style={{ backgroundColor: COLORS.BACKGROUNDBTNCOLOR }}
      ></SafeAreaView>
      <StatusBar
        backgroundColor={COLORS.BACKGROUNDBTNCOLOR}
        barStyle={"dark-content"}
      />
      <SafeAreaView style={{ flex: 1, backgroundColor: COLORS.WHITE }}>
        <Header
          navigation={props?.navigation}
          Heading={"Submit Your Query"}
          HeaderStyle={{ marginLeft: "14%" }}
        />

        <KeyboardAwareScrollView showsVerticalScrollIndicator={false}>
          <InputFiled
            InputFieldStyle={{
              width: WIDTH * 0.93,
              alignSelf: "center",
              marginTop: "6%",
              borderRadius: 10,
              borderColor: "#ECECEC",
              borderWidth: 1,
            }}
            placeholder={"Your name"}
            MaxLength={256}
            value={Name}
            onBlur={() => {
              if (Name != "" || Name != undefined) {
                setShowError((prevState) => ({
                  ...prevState,
                  fullNmError: true,
                }));
              }
            }}
            onEndEditing={() => {
              // Validate the phone number when the TextInput loses focus
              setNameerror(ValidateFullname(Name));
          }}
            onChangeText={(text: string) => {
              if (Name != "" || Name != undefined) {
                setName(text);
                // setNameerror(ValidateFullname(text));
              }
            }}
            ShowError={ShowError.fullNmError}
            Error={Nameerror}
            Errorstyle={{ right: "8%" }}
          />
          <InputFiled
            placeholder={"Your Email"}
            value={Email}
            MaxLength={256}
            InputFieldStyle={{
              width: WIDTH * 0.93,
              alignSelf: "center",
              borderRadius: 10,

              borderColor: "#ECECEC",
              borderWidth: 1,
            }}
            onBlur={() => {
              if (Email != "" || Email != undefined) {
                setShowError((prevState) => ({
                  ...prevState,
                  emailError: true,
                }));
              }
            }}
            onEndEditing={() => {
              // Validate the phone number when the TextInput loses focus
              setEmailError(ValidateEmail(Email));
          }}
            onChangeText={(text: string) => {
              if (Email != "" || Email != undefined) {
                setEmail(text);
                // setEmailError(ValidateEmail(text));
              }
            }}
            ShowError={ShowError.emailError}
            Error={EmailError}
            Errorstyle={{ right: "8%" }}
          />
          <InputFiled
            placeholder={"Your Phone number"}
            MaxLength={18}
            value={phone}
            keyboardType="number-pad"
            InputFieldStyle={{
              width: WIDTH * 0.93,
              alignSelf: "center",
              borderRadius: 10,

              borderColor: "#ECECEC",
              borderWidth: 1,
            }}
            onBlur={() => {
              if (phone != "" || phone != undefined) {
                setShowError((prevState) => ({
                  ...prevState,
                  phoneerror: true,
                }));
              }
            }}
            onEndEditing={() => {
              // Validate the phone number when the TextInput loses focus
              setPhoneError(ValidateMobileNumber(phone));
          }}
            onChangeText={(num: string) => {
              if (phone != "" || phone != undefined) {
                setPhone(num);
                // setPhoneError(ValidateMobileNumber(num));
              }
            }}
            ShowError={ShowError.phoneerror}
            Error={phoneError}
            Errorstyle={{ right: "8%" }}
          />
          <View style={styles.LargeView}>
            <TextInput
              style={styles.textinput}
              placeholder={"Message...."}
              placeholderTextColor={COLORS.PLACEHOLDERCOLOR}
              multiline={true}
              value={msg}
              onBlur={() => {
                setmsgError(ValidationMessgaeBox(msg));
                if (msg != "" || msg != undefined) {
                  setShowError((prevState) => ({
                    ...prevState,
                    messageError: true,
                  }));
                }
              }}
              onEndEditing={() => {
                // Validate the phone number when the TextInput loses focus
                setmsgError(ValidationMessgaeBox(msg));
            }}
              onChangeText={(Msgid: string) => {
                setMsg(Msgid);
                if (msgError) {
                  setmsgError(ValidationMessgaeBox(Msgid));
                }
                if (msg != "" || msg != undefined) {
                  setmsgError(ValidationMessgaeBox(msg));
                }
              }}
            />
          </View>
          {msgError && (
            <Text style={[styles.errorStyle, { marginLeft: "13%" }]}>
              {msgError}
            </Text>
          )}

          <WholeButton
            styles={{
              backgroundColor: COLORS.BACKGROUNDBTNCOLOR,
              color: COLORS.WHITE,
              marginTop: "9%",
            }}
            Label={"SUBMIT"}
            Action={() => {
              Submit();
            }}
          />
        </KeyboardAwareScrollView>
      </SafeAreaView>
      <SpiningLoader loader={Loader} />
      <SafeAreaView style={{ backgroundColor: "#fff" }}></SafeAreaView>
    </>
  );
};

export default SubmitYourQuery;

const styles = StyleSheet.create({
  LargeView: {
    backgroundColor: COLORS.WHITE,
    height: HEIGHT / 3.4,
    width: WIDTH * 0.92,
    alignSelf: "center",
    marginTop: "1%",
    borderRadius: 10,
    padding: "2%",
    borderColor: "#ECECEC",
    borderWidth: 1,
    color: "#262626",
  },
  errorStyle: {
    color: COLORS.ERRORCOLORRED,
    fontSize: 13,
    fontFamily: FONTS.medium,
    marginTop: 2,
    fontWeight: "400",
    right: "6%",
    width: WIDTH * 0.9,
    alignSelf: "center",
  },
  textinput: {
    color: "#262626",
    paddingLeft: 10,
    paddingRight: 10,
    fontSize: 15,
    fontFamily: FONTS.regular,
    height: HEIGHT / 3.7,
    textAlignVertical: "top",
  },
});
