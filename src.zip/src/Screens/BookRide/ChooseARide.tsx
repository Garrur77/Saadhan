import React, { useRef, useEffect, useState, useMemo, useCallback } from 'react'
import { StyleSheet, Text, TouchableOpacity, View, Platform, StatusBar, FlatList, Alert, Image, ActivityIndicator } from 'react-native'
import { FONTS, VECTOR_ICONS, COLORS, IMAGEPATH } from '../../assets/Theme'
import MapBackground from '../../Components/GlobalBackground/MapBackground'
import { HEIGHT, WIDTH } from '../../Components/Helpers/Dimentions'
import RBSheet from "react-native-raw-bottom-sheet";
import { CommonActions, useFocusEffect, useIsFocused, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context'
import axios from 'axios'
import { showMessage } from 'react-native-flash-message'
import { cancelRide, createRide, fetchVehiclefares } from '../../ApiConfig/Endpoints'
import CarSvg from '../../Components/SvgComponent/CarRide/CarSvg'
import Limousine from '../../Components/SvgComponent/ChooseARide/Limousine'
import ConfirmPickupSpot1 from '../../Components/RBSheetComponents/ConfirmPickupSpot1'
import ModalComponent from '../../Components/ModalComponent/ModalComponent'
import WholeButton from '../../Components/Wholebutton/Wholebutton'
import HandSvg from '../../Components/SvgComponent/CarRide/HandSvg'
import { useDispatch, useSelector } from 'react-redux'
import { RootState } from '../../ReduxConfig/Store'
import SpiningLoader from '../../assets/SpiningLoader'
import BookConfirmpopup from '../../Components/RBSheetComponents/BookConfirmpopup'
import CancelYourRide from '../../Components/RBSheetComponents/CancelYourRide'
import { SOCKET_URL } from '../../ApiConfig/Endpoints'
import io from 'socket.io-client';
import MapView, { Marker, Polyline } from 'react-native-maps'
import BikeSvg from '../../Components/SvgComponent/CarRide/BikeSvg'
import RateModalComponent from '../../Components/ModalComponent/RateModalComponent'
import { setClearRideData, setSaveRideData } from '../../ReduxConfig/Location/locationSlice'
import { BottomSheetModal, BottomSheetModalProvider } from '@gorhom/bottom-sheet'
import { GestureHandlerRootView } from 'react-native-gesture-handler'
import MapViewDirections from 'react-native-maps-directions'
import socketServcies from '../../Utils/SocketService'
import { setOpenModal } from '../../ReduxConfig/UserDetails/UserSlice'

const ChooseARide = (props: any) => {
    const [modalType,setModalType]  = useState("vehicleFetch")
    // let modalType = "vehicleFetch"
    // ["vehicleFetch", "comfirmVehicle","confirmPickUp"]
    const loctionData = useSelector(
        (state: RootState) => state?.locationSelector?.userCoordinated
    );
    const [loader, setLoader] = useState(false)
    const [loading, setLoading] = useState(false)
    const bottomSheetRef = useRef(null);
    const bottomSheetRef1 = useRef(null);
    const bottomSheetRef3 = useRef(null);
    const bottomSheetRef4 = useRef(null);
    const bottomSheetRef5 = useRef(null);
    const [vehicles, setVechileType] = useState("")
    const [selectedItemIndex, setSelectedItemIndex] = useState(-1);
    const [selectedData, setSelectData] = useState("");
    const [drivers, setDrivers] = useState([]);
    const [rideCreateID, setRideCReateID] = useState("");
    const [rideID, setIDRide] = useState("");
    const [driversNear, setDriversNear] = useState([]);
    const [modalVisible, setModalVisible] = useState(false)
    const [modalVisibleReson, setModalVisibleReson] = useState(false)
    const [modalVisibleRate, setModalVisibleRate] = useState(false)
    const [vehicleDetails, setVehicleDetails] = useState("")
    const [rideDetails, setRideDetails] = useState("")
    console.log("selectedDataselectedData", selectedData);
    const [selectedReasonRide, setReasonRide] = useState("The waiting period was excessively lengthy.")
    const [fetchDetails, setFetchDetails] = useState([])
    const dispatch = useDispatch()
    const Data = useSelector(
        (state: RootState) => state.userDetails?.profileData
    );


    console.log("ghhhggghgghghghghghgh", Data)
    console.log("vehicleDetails------>>99999>-----", vehicleDetails)
    // const [userId, setUserId] = useState(Data?._id);
    // const Data = useSelector(
    //     (state: RootState) => state.USERID_
    // );


    const Isfocus = useIsFocused()

    const snapPoints = useMemo(() => ["2%", "44%"], []);
    const snapPoints3 = useMemo(() => ["2%", "40%"], []);
    const bottomSheetModalRef2 = useRef(null);
    const bottomSheetModalRef3 = useRef(null);

    useEffect(() => {
        // Function to open the modal when the screen is focused
        handlePresentModalPress();

    }, []);

    const handlePresentModalPress = useCallback(() => {
        bottomSheetModalRef2.current?.present();
    }, []);
    const handlePresentModalPress1 = useCallback(() => {
        bottomSheetModalRef2.current?.close();
    }, []);
    const handlePresentModalPress3 = useCallback(() => {
        handlePresentModalPress1();
        setModalType("comfirmVehicle")
        // modalType = "comfirmVehicle";
        bottomSheetModalRef3.current?.present();
    }, []);
    const handlePresentModalPress3Close = useCallback(() => {
        bottomSheetModalRef3.current?.close();
    }, []);
    const handleSheetChanges = useCallback((index: number) => {
        console.log("handleSheetChanges", index);
    }, []);
    const handleSheetChanges3 = useCallback((index: number) => {
        console.log("handleSheetChanges", index);
    }, []);



    const myRef = useRef(null)

    const currentLog = props?.route?.params?.currentLatlog;
    const dropLatLog = props?.route?.params?.dropLatLog;
    const pickupAddress = props?.route?.params?.pickupAddress;
    const dropAddress = props?.route?.params?.dropAddress;
    const navigation = useNavigation()

    const [nearbyDrivers, setNearByDrivers] = useState([])
    const [intialLocation, setIntialLocation] = useState({
        latitude: loctionData?.coords?.latitude ?? "28.5355",
        longitude: loctionData?.coords?.longitude ?? "77.3910",
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
    });





    useEffect(() => {
        // Connect to the socket when the component mounts

        console.log("socket calll first time-------");
        socketServcies.on('newRide', (response) => {
            console.log('new rider Data callinedff000', response);
            if (response) {
                console.log("useEffect event---mappedNearestDrivers", response?.nearestVehicleTypes?.mappedNearestDrivers);
                setFetchDetails(response?.nearbyDrivers)
            } else {
                console.log("Socket ride else conditon check----");
            }

        });

    }, []);

    useEffect(() => {
        const newSocket = io(SOCKET_URL, {
            transports: ["websocket"],
            reconnection: true, // Enable reconnection
            reconnectionAttempts: 5, // Number of reconnection attempts before giving up
            reconnectionDelay: 1000, // Initial delay before attempting to reconnect (in milliseconds)
            reconnectionDelayMax: 5000, // Maximum delay between reconnection attempts
            randomizationFactor: 0.5,
        });

        newSocket.on("connect", () => {
            console.log("Socket connected");
        });
        newSocket.on("newRide", (response) => {
            setRideCReateID(response?.rideId); // Assuming rideId is received from response
            if (response) {
                setFetchDetails(response?.nearbyDrivers)
                newSocket.on("rideDetails", (response) => {
                    console.log("rideDetails---->>>C", response)
                    if (response?.riderDetails?.riderId === Data?._id) {
                        console.log("8888888888810===1-c", response?.riderDetails?.riderId);
                        console.log("99999999910===-1-c", Data?._id);
                        dispatch(setSaveRideData(response))
                        setRideDetails(response)
                    }
                });

            }
        });


        newSocket.on("disconnect", (reason) => {
            console.log("Socket disconnected:", reason);
        });

        return () => {
            newSocket.disconnect();
        };
    }, []);

    const CreateRiderBookingHandler = async () => {
        try {
            setLoader(true);
            const data = {
                userId: Data?._id,
                startLocation: currentLog,
                endLocation: dropLatLog,
                pickupAddress: pickupAddress,
                destinationAddress: dropAddress,
                vehicleType: selectedData?.vehicleType,
                fareAmount: selectedData?.fare,
                paymentMethod: 'cash',
            }
            console.log("createRidecreateRide", data)
            socketServcies.emit('createRide', data);
            // Listen for the response
            socketServcies.on('createRideResponse', (response) => {
                console.log("setIDRidesetIDRide", response)
                if (response?.responceCode === 200) {
                    dispatch(setClearRideData({}))
                    console.log("Ride is created")
                    setVehicleDetails(response?.resp);
                    setIDRide(response?.rideId)
                    closedRbSheet3();
                    setLoader(false);
                    if (response?.rideId) {
                        console.log("check55 --===123456", response?.resp?.vehicleType);
                        console.log("check55 --===123456999---", response);
                        const data = {
                            rideId: response?.rideId,
                            pickupLocation: response?.pickupLocation,
                            vehicleType: response?.vehicleType,
                            destinationLocation: response?.destinationLocation,
                            pickupAddress: response?.resp?.pickupAddress,
                            destinationAddress: response?.resp?.destinationAddress
                        }
                        console.log("createRideResponse,createRideResponse", data);
                        socketServcies.emit("rideCreated", {
                            rideId: response?.rideId,
                            pickupLocation: response?.pickupLocation,
                            vehicleType: response?.vehicleType,
                            destinationLocation: response?.destinationLocation,
                            pickupAddress: response?.resp?.pickupAddress,
                            destinationAddress: response?.resp?.destinationAddress
                        });
                    } else {
                        console.log("erroro ride else conditon check----");
                    }
                    // ... other actions you want to perform on success
                } else {
                    console.log("Socket ride else conditon check----");
                    // ... handle other cases
                }
            });
        } catch (error) {
            setLoader(false);
            console.log("error--createRide-createRideResponse", error)
        }
    };

    function getEstimatedTimes(value) {
        return value || 0;
    }

    function toFixedOrDefault(number) {
        // Parse the input as a float, or use 0 if it's not a valid number
        const parsedNumber = parseFloat(number);

        // Check if the parsedNumber is a valid number
        if (!isNaN(parsedNumber)) {
            // If it's a valid number, format it to two decimal places
            return parsedNumber.toFixed(2);
        } else {
            // If it's not a valid number or blank, return '0.0'
            return '0.0';
        }
    }


    const closeTheModalCancelRiderHandler = () => {
        if (bottomSheetRef4.current) {
            bottomSheetRef4.current.close();
            console.log("closed the loader screen");
        }
        setTimeout(() => {
            try {
                props?.navigation?.dispatch(
                    CommonActions.reset({
                        index: 0,
                        routes: [{ name: "BottomTabBar" }],
                    })
                );
            } catch (error) {
                console.error("Navigation error: ", error);
            }
        }, 500);
    };


    const CancleRideSocketResponse = () => {
        socketServcies.on("yourRideCancled", (response) => {
            console.log("jjjjjjfjfjfjfjfjfjfjf====888", response, Data?._id)
            if (response?.riderId === Data?._id) {
                showMessage({
                    message: "Your ride is cancelled by driver !!!!",
                    type: "danger",
                    duration: 3000
                })
                closeTheModalCancelRiderHandler();
            }
        })
    }

    const CancelRiderRequestHandler = async () => {
        setLoader(true);
        axios({
            method: "POST",
            url: cancelRide,
            data: {
                userId: Data?._id,
                rideId: rideID,
                reason: selectedReasonRide ?? "I made the request unintentionally.",
            },
        })
            .then((response) => {
                if (response.data.responceCode === 200) {
                    setModalVisibleReson(false);
                    setLoader(false);
                    showMessage({
                        message: response?.data?.message,
                        type: "success",
                        icon: "success",
                        duration: 1000,
                    });
                    setTimeout(() => {
                        props?.navigation?.dispatch(
                            CommonActions.reset({
                                index: 0,
                                routes: [{ name: "BottomTabBar" }],
                            })
                        )
                    }, 500)
                } else {
                }
            })
            .catch((err) => {
                console.log("cancel ride errrooorrrorror", err);
                setLoader(false);
            })
    };

    const closeBottomSheet1 = () => {
        handlePresentModalPress3Close();
        // modalType = "confirmPickUp";
        if (bottomSheetRef3.current) {
            console.log("asdadasd bottomSheetRef3")
            setTimeout(() => {
                bottomSheetRef3.current.open();
                console.log("asdadasd bottomSheetRef3 open")
            }, 300)

        }

    }

    const closeBottomSheet1Sucss = () => {
        console.log("asdadasd")
        if (bottomSheetRef3.current) {
            bottomSheetRef3.current.close();
            navigation?.navigate("RideCompletedComp", {
                data: rideID,
                currentLog: currentLog,
                dropLatLog: dropLatLog
            });



        }


    }
    const closeTheModalCancelRider = () => {
        if (bottomSheetRef4.current) {
            bottomSheetRef4.current.close();
            console.log("asdadasd bottomSheetRef1")
            setTimeout(() => {
                bottomSheetRef5.current.open();
                console.log("asdadasd bottomSheetRef3 open")
            }, 300)
        }

    }

    const closeDataChat = () => {
        if (bottomSheetRef4.current) {
            console.log("asdadasd bottomSheetRef3")
            setTimeout(() => {
                bottomSheetRef4.current.close();
                props?.navigation?.navigate("ChatDrivertoUser", { data: rideDetails })
                console.log("asdadasd bottomSheetRef3 open")
            }, 300)
        }

    }

    const CancelReasonModal = () => {
        if (bottomSheetRef5.current) {
            bottomSheetRef5.current.close();
            console.log("asdadasd bottomSheetRef1")

        } setTimeout(() => {
            setModalVisibleReson(true)
        }, 300)

    }

    const closedRbSheet3 = () => {
        console.log("asdadasd")
        if (bottomSheetRef3.current) {
            bottomSheetRef3.current.close();
            console.log("asdadasd bottomSheetRef1")

        } setTimeout(() => {
            setModalVisible(true)
        }, 300)
    }

    const FetchVichelesTypes = async () => {
        setLoading(true);
        axios({
            method: "POST",
            url: fetchVehiclefares,
            data: {
                startLocation: currentLog,
                endLocation: dropLatLog,
            },
        })
            .then((response) => {
                if (response.data.responceCode === 200) {
                    console.log("response=========", response?.data)
                    setVechileType(response?.data)
                    setDrivers(response?.data?.nearestVehicleTypes)
                    setLoading(false);
                } else {
                }
            })
            .catch((err) => {
                console.log("=============errroroor=======================", err.response?.data);
                setLoading(false);
            });
    };

    useEffect(() => {
        // Mock data (replace this with your actual JSON response)
        const responseData = drivers;
        // Extracting driver locations
        const driverLocations = Object.values(responseData)
            .flatMap(vehicle => vehicle?.mappedNearestDrivers?.map(driver => driver?.driverLocation));
        setDriversNear(driverLocations);
    }, [drivers]);


    useEffect(() => {
        FetchVichelesTypes();
    }, [Isfocus]);

    interface DataItem {
        vehicle: any;
        text1: string;
        text2: string;
        price: string;
        time: any;
    }

    const getVehicleSvg = (vehicleType) => {
        switch (vehicleType) {
            case "sedan":
                return <CarSvg />;
            case "Uber Go":
                return <Limousine />;
            case "Uber Moto":
                return <Limousine />;
            case "car":
                return <CarSvg />;
            case "CAR":
                return <CarSvg />;
            case "car1":
                return <CarSvg />;
            case "premium":
                return <CarSvg />;
            case "New Car 2":
                return <CarSvg />;
            case "Car":
                return <CarSvg />;
            case "Car 3":
                return <CarSvg />;
            case "New Car":
                return <CarSvg />;
            case "Auto":
                return <Limousine />;
            case "Uber Go Sedan":
                return <Limousine />;
            case "Uber Premier":
                return <Limousine />;
            case "Car":
                return <Limousine />;
            case "Bike":
                return <BikeSvg />;
            case "bike":
                return <BikeSvg />;
            case "auto":
                return <Limousine />;
            // Add cases for other vehicle types
            default:
                return <CarSvg />;
        }
    };

    const DATA: DataItem[] = (vehicles?.nearestVehicleTypes
        ? Object.keys(vehicles.nearestVehicleTypes).map((key) => ({
            vehicleType: key,
            count: vehicles.nearestVehicleTypes[key].count,
            count: vehicles.nearestVehicleTypes[key].mappedNearestDrivers,
            estimatedTimes: vehicles.nearestVehicleTypes[key].estimatedTimes,
            distancekms: vehicles.nearestVehicleTypes[key].distancekms,
            fare: vehicles.allFares[key] ? vehicles.allFares[key].fare : null,
            vehicleIcon: getVehicleSvg(key)
        }))
        : []);



    const Ridetails = useSelector(
        (state: RootState) => state?.rideDetailsSelector?.RideDetails
    );

    //SOCKET to end ride
    const endRide = () => {
        socketServcies?.on("rideEnded", (response) => {
            console.log("completed===completed", response?.ridedata?.status);
            console.log("tttetetetetetetete2", response)
            if (response?.ridedata?.status === "completed" && response?.ridedata?.riderId?._id === Data?._id) {
                bottomSheetRef4.current.close();
                setTimeout(() => {
                    setModalVisibleRate(true);
                }, 300)
                // setModalVisibleRate(true)
                console.log("setModalVisibleRate")
            }
        });
    };



    //SOCKET to fetch nearby drivers
    const NearByDrivers = () => {
        const lat = loctionData?.coords?.latitude;
        const lng = loctionData?.coords?.longitude;
        console.log("cureent latttt---", lat);
        console.log("current long", lng);
        socketServcies.emit("checkNearbyDriver", { lat, lng }, (response) => {
            console.log("socket emited for nearby Drivers", response)
        })
        socketServcies.on("nearbyDriver", (response) => {
            console.log("NearBy----Drivers--->>", response)
            if (response) {
                setNearByDrivers(response)
            }
        })
    }



    useEffect(() => {
        endRide();
        CancleRideSocketResponse();
        NearByDrivers();
        FetchVichelesTypes();
    }, [Isfocus])


    useFocusEffect(
        React.useCallback(() => {
            if (bottomSheetRef.current) {
                bottomSheetRef.current.open();
            }
            return () => {
                // any cleanup operations if necessary
            };
        }, [bottomSheetRef,])
    );
    const sheetheight = Platform.OS === 'ios' ? 400 : 400;

    // let modalType = "vehicleFetch" 
    // ["vehicleFetch", "comfirmVehicle","confirmPickUp"]
console.log("modalTypemodalTypemodalType",modalType)
    const backHandler = () => {
        if (modalType === "comfirmVehicle") {
            handlePresentModalPress3Close();
            if (bottomSheetModalRef2?.current) {
                setModalType("vehicleFetch");
                setTimeout(() => {
                    bottomSheetModalRef2.current?.present();
                }, 500);
            }
        } 
        else if (modalType === "vehicleFetch") {
            dispatch(setOpenModal(true));
            props.navigation.navigate("BottomTabBar");
        }
         else {
            dispatch(setOpenModal(true));
            props.navigation.navigate("BottomTabBar");
        }
    };
    
    
    return (
        <>
            <SafeAreaView style={{ flex: 1, backgroundColor: 'transparent' }}>
                <GestureHandlerRootView style={{ flex: 1, }}>

                    <MapView
                        ref={myRef}
                        style={{
                            position: "absolute",
                            top: 0,
                            right: 0,
                            bottom: 0,
                            left: 0,
                            height: HEIGHT,
                          }}
                        // style={StyleSheet.absoluteFill}
                        initialRegion={intialLocation}
                        zoomTapEnabled={true}
                        zoomEnabled={true}
                        scrollEnabled={true}
                        // showsScale={true}
                        // onRegionChange={(region) => {
                        //     console.log("regionss", region);
                        //     // setIntialLocation({ ...intialLocation });
                        // }}
                    >
                        <MapViewDirections
                            origin={{ latitude: currentLog?.lat, longitude: currentLog?.lng }}
                            destination={{ latitude: dropLatLog?.lat, longitude: dropLatLog?.lng }}
                            apikey="AIzaSyCzU4XQ6D43-mEnHWZ5l3vobePxE6p2GRw"
                            strokeWidth={5}
                            strokeColor="rgba(255, 85, 0, 1)"
                        />
                        <Marker coordinate={{ latitude: currentLog?.lat, longitude: currentLog?.lng }} >
                            <Image source={require("../../assets/Images/current.png")} style={{ width: 35, height: 35 }} />
                        </Marker>

                        <Marker coordinate={{ latitude: dropLatLog?.lat, longitude: dropLatLog?.lng }} >
                            <Image source={require("../../assets/Images/ic_Pin.png")} style={{ width: 35, height: 45 }} />
                        </Marker>
                        {nearbyDrivers?.map(driver => (
                            <Marker
                                key={driver?._id}
                                coordinate={{
                                    latitude: driver.location.coordinates[0],
                                    longitude: driver.location.coordinates[1]
                                }} >
                                <Image source={IMAGEPATH.newCar} style={{ width: 35, height: 35 }} />
                            </Marker>)

                        )}
                    </MapView>

                    <View style={styles.mainView}>
                        <TouchableOpacity style={styles.backIcon} onPress={backHandler}>
                            <VECTOR_ICONS.Ionicons name="chevron-back" size={26} color={''} style={{ alignSelf: "center" }} />
                        </TouchableOpacity>
                        {/* --------------------------  Fetch Vehicle -------------------------*/}
                        <BottomSheetModalProvider>
                                <BottomSheetModal
                                    ref={bottomSheetModalRef2}
                                    index={1}
                                    handleIndicatorStyle={{
                                        backgroundColor: "rgba(155, 155, 155, 1)",
                                        width: 70,
                                        height: 6
                                    }}
                                    backgroundStyle={{
                                        backgroundColor: "#fff",

                                    }}
                                    snapPoints={snapPoints}
                                    onChange={handleSheetChanges}
                                    enablePanDownToClose={false}
                                    enableContentPanningGesture={false}
                                >

                                    <View>

                                        <FlatList
                                            scrollEnabled={true}
                                            showsVerticalScrollIndicator={false}
                                            // style={{ marginVertical: "1%", marginBottom: "5%" }}
                                            data={DATA}
                                            contentContainerStyle={{ paddingBottom: 30 }}
                                            ListEmptyComponent={() => (
                                                <View style={{ justifyContent: 'center', alignItems: 'center', height: HEIGHT * 0.2 }}>
                                                    <ActivityIndicator size='large' color={COLORS.YOUR_LOADER_COLOR} />

                                                    {/* <Text style={{ fontSize: 16, color: '#000' }}>No Vehicle found</Text> */}
                                                </View>
                                            )}
                                            ItemSeparatorComponent={() => (
                                                <View
                                                    style={{
                                                        height: 1,
                                                        width: "100%",
                                                        backgroundColor: "#CED0CE", // You can customize the separator color
                                                    }}
                                                />
                                            )}

                                            renderItem={({ item, index }: { item: DataItem; index: number }) => {
                                                console.log("-----------", item)
                                                return (
                                                    <View >
                                                        <TouchableOpacity
                                                            style={[
                                                                styles.locationview,
                                                                {
                                                                    backgroundColor:
                                                                        selectedItemIndex === index ? "#F50" : "white",
                                                                    paddingVertical: 15,
                                                                    paddingHorizontal: 10,

                                                                },
                                                            ]}
                                                            onPress={() => {
                                                                setSelectedItemIndex(index);
                                                                setSelectData(item)
                                                                handlePresentModalPress3()
                                                                // openBottomSheet1();
                                                            }}
                                                        >
                                                            <View
                                                                style={{
                                                                    flexDirection: "row",
                                                                    alignItems: "center",
                                                                    justifyContent: "center",
                                                                    marginHorizontal: 10
                                                                }}
                                                            >
                                                                <View>{item.vehicleIcon}</View>
                                                                <View style={{ width: WIDTH * 0.3, marginLeft: "7%" }}>
                                                                    <Text numberOfLines={1} style={[styles.canceltext, { fontWeight: "600", color: selectedItemIndex === index ? "#fff" : "rgba(36, 46, 66, 1)" , textTransform: "capitalize"}]}>{item?.vehicleType}</Text>
                                                                    <Text style={[styles.mobiloitte, { color: selectedItemIndex === index ? "#fff" : "#C8C7CC", paddingTop: 6, fontSize: 16 }]}>
                                                                        {item?.distancekms}
                                                                        {/* {toFixedOrDefault(item?.distancekms)} km */}
                                                                    </Text>
                                                                </View>
                                                            </View>
                                                            <View
                                                                style={{ alignItems: 'flex-end', justifyContent: "flex-end", marginRight: 15 }}
                                                            >
                                                                <Text style={[styles.canceltext, { fontWeight: "600", color: selectedItemIndex === index ? "#fff" : "rgba(36, 46, 66, 1)" }]} >
                                                                    ${toFixedOrDefault(item?.fare)}
                                                                </Text>
                                                                <Text style={[styles.mobiloitte, { fontSize: 16, color: selectedItemIndex === index ? "#fff" : "#C8C7CC", paddingTop: 6, fontWeight: "400" }]}>
                                                                    {item?.estimatedTimes}
                                                                    {/* {getEstimatedTimes(item?.estimatedTimes)} */}
                                                                </Text>
                                                            </View>
                                                        </TouchableOpacity>
                                                    </View>
                                                );
                                            }}
                                        />
                                    </View>


                                </BottomSheetModal>
                        </BottomSheetModalProvider>
                        {/* --------------------------  Confirm Vehicle -------------------------*/}
                        <BottomSheetModalProvider>
                            <View style={styles.container}>
                                <BottomSheetModal
                                    ref={bottomSheetModalRef3}
                                    index={1}
                                    handleIndicatorStyle={{
                                        backgroundColor: "rgba(155, 155, 155, 1)",
                                        width: 70,
                                        height: 6
                                    }}
                                    //   backgroundStyle={{
                                    //     backgroundColor:"transparent"
                                    //   }}
                                    snapPoints={snapPoints3}
                                    onChange={handleSheetChanges3}
                                    enablePanDownToClose={false}
                                    enableContentPanningGesture={false}
                                >

                                    <View style={[styles.mainView, {}]}>
                                        <View style={[styles.locationview, { paddingHorizontal: 20, paddingTop: 15 }]}>
                                            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "center" }}>
                                                {selectedData?.vehicleIcon}
                                                <View style={{ width: WIDTH * 0.3, marginLeft: "7%" }}>
                                                    <Text style={styles.canceltext}>{selectedData?.vehicleType}</Text>
                                                    <Text style={[styles.mobiloitte, { paddingTop: 6 }]}>
                                                        {selectedData?.distancekms}
                                                        {/* {toFixedOrDefault(selectedData?.distancekms)} */}
                                                    </Text>
                                                </View>
                                            </View>
                                            <View style={{ alignItems: "center", justifyContent: "center", }}>
                                                <Text numberOfLines={1} style={[styles.canceltext, { color: COLORS.BACKGROUNDBTNCOLOR, fontSize: 17 }]}>
                                                    ${toFixedOrDefault(selectedData?.fare)}
                                                </Text>
                                                <Text style={[styles.mobiloitte, { fontSize: 15 }]}>
                                                    {selectedData?.estimatedTimes}
                                                    {/* {getEstimatedTimes(selectedData?.estimatedTimes)} */}
                                                </Text>
                                            </View>
                                        </View>
                                        <View style={styles.lineStyle}></View>
                                        <Text style={[styles.mobiloitte, { fontSize: 14, color: '#8A8A8F', paddingVertical: 5, paddingLeft: 20 }]}>Payment Options</Text>
                                        <View style={[styles.locationview, { paddingTop: 10, paddingLeft: 10 }]}>
                                            <View style={styles.handmainview}>
                                                <HandSvg />
                                                <Text style={[styles.mobiloitte, { marginLeft: "10%", color: "rgba(36, 46, 66, 1)" }]}>Cash</Text>
                                            </View>
                                            <TouchableOpacity onPress={props.cashAction}
                                                style={styles.dotsstyle}>
                                                {/* <VECTOR_ICONS.Entypo name={"dots-three-vertical"} size={25} color={"rgba(218, 218, 218, 1)"} /> */}
                                            </TouchableOpacity>
                                        </View>
                                        <View style={{ paddingVertical: 25 }}>
                                            <WholeButton Label={"Confirm"} styles={styles.backbtn} Action={() => closeBottomSheet1()} />
                                        </View>
                                    </View>


                                </BottomSheetModal>
                            </View>
                        </BottomSheetModalProvider>
                        {/* --------------------------  Confirm Pick up Location -------------------------*/}
                        <RBSheet
                            ref={bottomSheetRef3}
                            // onClose={()=>{openModal()}}
                            height={290}
                            closeOnPressMask={false}
                            customStyles={{
                                container: styles.firstView1,
                                draggableIcon: { opacity: 0 },
                            }}
                        >

                            <ConfirmPickupSpot1 Action1={() => {bottomSheetRef3.current.close()
                        if(bottomSheetModalRef3?.current){
                            setTimeout(()=>{
                                bottomSheetModalRef3?.current?.present();

                            },300)
                        }    
                        }}
                                pickupAddress={pickupAddress}
                                Action={() => { CreateRiderBookingHandler() }}
                                
                                Action2={() => {
                                    bottomSheetRef3?.current?.close()
                                    navigation?.navigate("BottomTabBar")
                                }}
                            />
                        </RBSheet>
                        {/* {getEstimatedTimes(item?.estimatedTimes)} min */}

                        <ModalComponent
                            setModalVisible={setModalVisible}
                            modalVisible={modalVisible}
                            Message={'Your Ride has been waiting for drivers.'}
                            Message1={`Driver will pickup you in ${selectedData?.estimatedTimes}.`}
                            head={'Ride Created Successfully'}
                            Button={'Okay'}
                            Action2={() => {
                                setModalVisible(false);
                                closeBottomSheet1Sucss()
                            }}
                            source={IMAGEPATH.success}
                            imgstyle={{ marginTop: '0%' }}
                            modalstyle={{
                                paddingVertical: '6%',
                            }}
                        />

                        <RBSheet
                            ref={bottomSheetRef4}
                            // onClose={()=>{openModal()}}
                            height={330}
                            closeOnPressMask={false}
                            customStyles={{
                                container: styles.firstView1,
                                draggableIcon: { opacity: 0 },

                            }}
                        >

                            <BookConfirmpopup
                                Action1={() =>
                                    closeTheModalCancelRider()}
                                vehicleDetails={vehicleDetails}
                                // Action2={() => {
                                //     RateModalFunctionOpen();
                                //   }}
                                // rideDetails={rideDetails}
                                Ridetails={rideDetails}
                                Action={() => { closeDataChat() }}

                            />
                        </RBSheet>

                        <RBSheet
                            ref={bottomSheetRef5}
                            // onClose={()=>{openModal()}}
                            height={410}
                            closeOnPressMask={false}
                            customStyles={{
                                container: styles.firstView1,
                                draggableIcon: { opacity: 0 },
                            }}
                        >

                            <CancelYourRide
                                setReasonRide={(e) => setReasonRide(e)}
                                selectedReasonRide={selectedReasonRide}
                                Action1={() => bottomSheetRef5.current.close()}
                                vehicleDetails={vehicleDetails}
                                Action={() => { CancelReasonModal() }}
                            />
                        </RBSheet>

                        <ModalComponent
                            setModalVisible={setModalVisibleReson}
                            modalVisible={modalVisibleReson}
                            Message={'Are you sure, you want to cancel your'}
                            Message1={'ride?'}
                            head={'Cancel Your Ride'}
                            Button12
                            btn1={'Back'}
                            btn2={'Confirm'}
                            // navigated={()=>{setModalVisible(false);}}
                            navigated={() => {
                                setModalVisibleReson(false),
                                    setTimeout(() => {
                                        props?.navigation?.dispatch(
                                            CommonActions.reset({
                                                index: 0,
                                                routes: [{ name: "BottomTabBar" }],
                                            })
                                        )
                                    }, 500)
                            }}

                            Action={() => {
                                CancelRiderRequestHandler()
                                console.log("the ride is cancelled,confirm button")
                                // setModalVisibleReson(false);
                                // props.navigation.navigate('AfterStartingRide');
                            }}
                            source={IMAGEPATH.cancle}
                            imgstyle={{}}
                            modalstyle={{
                                // height:platformType==='ios'? 284:  HEIGHT*0.38,
                            }}
                        />

                        <RateModalComponent
                            setModalVisible={setModalVisibleRate}
                            modalVisible={modalVisibleRate}
                            rate={'Rate Your Driver'}
                            head={'Ride Finished'}
                            Message={'Cash Paid - $24.89'}
                            img
                            Button="Submit"
                            Action2={() => {
                                setModalVisibleRate(false);
                                props.navigation.navigate('BottomTabBar')
                            }}
                            source={IMAGEPATH.success}
                            imgstyle={{ width: 48, height: 48, resizeMode: 'cover' }}
                            modalstyle={{
                                width: WIDTH * 0.75,
                            }}
                            msgstyle={{ fontSize: 16, color: '#242E42' }}
                        />

                        {/* Confirm pickup Addresss modal */}
                    </View>

                </GestureHandlerRootView>
                {/* {loading && <SpiningLoader loader={loading} />} */}
            </SafeAreaView>
            {/* <SafeAreaView style={{ backgroundColor: "#fff" }}></SafeAreaView>    */}
        </>
    )
}


export default ChooseARide

const styles = StyleSheet.create({
    mainView: { width: WIDTH * 1, flex: 1, alignSelf: "center", position: 'relative' },
    backIcon: {
        backgroundColor: "rgba(0, 0, 0, 0.1)",
        width: 46,
        height: 46,
        borderRadius: 23,
        marginVertical: "5%",
        alignItems: "center",
        justifyContent: "center",
        marginLeft: 10
    },
    map: {
        ...StyleSheet.absoluteFillObject,
    },
    handmainview: { flexDirection: "row", alignItems: "center", justifyContent: "center" },

    lineStyle: {
        borderBottomColor: "rgba(239, 239, 244, 1)",
        borderBottomWidth: 2,
        width: WIDTH,
        alignSelf: "center",
        marginVertical: "2%"
    },
    dotsstyle: { alignItems: "center", justifyContent: "center" },

    firstView1: {
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        backgroundColor: COLORS.WHITE,
    },
    locationview: {
        flexDirection: "row",
        // marginVertical: HEIGHT * 0.01,
        width: WIDTH * 1,
        alignSelf: "center",
        alignItems: "center",
        justifyContent: "space-between",


    },
    backbtn: {
        marginVertical: "1%",
        width: WIDTH * 0.9,
    },
    mobiloitte: {
        fontFamily: FONTS.medium,
        fontSize: 15,
        color: "#C8C7CC",
    },
    canceltext: {
        fontFamily: FONTS.bold,
        fontSize: 17,
        color: "rgba(36, 46, 66, 1)",
        textTransform: "capitalize"
    },


})

