import React, { useRef, useState, useEffect, useCallback, useMemo } from "react";
import { View, Image, Animated, SafeAreaView, StyleSheet, TouchableOpacity, Text, Linking, StatusBar, PermissionsAndroid, Platform, AppState } from "react-native";
import MapView, { AnimatedRegion, Marker } from "react-native-maps";
import MapViewDirections from "react-native-maps-directions";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../ReduxConfig/Store";
import { CommonActions, useIsFocused, useNavigation } from "@react-navigation/native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { HEIGHT, WIDTH } from "../../Components/Helpers/Dimentions";
import { COLORS, FONTS, IMAGEPATH, VECTOR_ICONS } from "../../assets/Theme";
import { BottomSheetModal, BottomSheetModalProvider } from "@gorhom/bottom-sheet";
import RateModalComponent from "../../Components/ModalComponent/RateModalComponent";
import ModalComponent from "../../Components/ModalComponent/ModalComponent";
import CancelYourRide from "../../Components/RBSheetComponents/CancelYourRide";
import BookConfirmpopup from "../../Components/RBSheetComponents/BookConfirmpopup";
import io from "socket.io-client";
import { SOCKET_URL, cancelRide, createSOS, rateDriver } from "../../ApiConfig/Endpoints";
import { showMessage } from "react-native-flash-message";
import axios from "axios";
import { setLocation } from "../../ReduxConfig/UserLocationSlice";
import Geolocation from "@react-native-community/geolocation";
import BackgroundTimer from "react-native-background-timer";
import { setSavedCordinated, setUserLocation } from "../../ReduxConfig/Location/locationSlice";
import socketServcies from "../../Utils/SocketService";

const YourComponent = (props: any) => {
  const myRef = useRef(null);
  const markerRef = useRef();
  const dropLatLog = props?.route?.params?.dropLatLog;
  const currentLog = props?.route?.params?.currentLog;
  const RideID = props?.route?.params?.data;  


  const loctionData = useSelector(
    (state: RootState) => state?.locationSelector?.userCoordinated
  )

  // console.log("latitudeeeeeeeee",loctionData?.coords?.latitude)
  // console.log("longitudeeeeeeee" ,loctionData?.coords?.longitude)

  const [loader, setLoader] = useState(false);
  const [acceptOTP, setAcceptOTP] = useState(false);
  const bottomSheetRef = useRef(null);
  const [modalVisibleRate, setModalVisibleRate] = useState(false);
  const dispatch = useDispatch();

  // const Data = useSelector((state: RootState) => state.USERID_);
  const Data = useSelector(
    (state: RootState) => state.userDetails?.profileData
  );

  const Tokens = useSelector(
    (state: RootState) => state.value
  );
  const Location = useSelector((state: RootState) => state.userLocationSlice);
  const token = Tokens?.RegisterTOKEN;
  const Isfocus = useIsFocused();
  const navigation = useNavigation();
  const [SelectStar, setSelectStar] = useState(0);
  const [selectedReasonRide, setReasonRide] = useState("The waiting period was excessively lengthy.");
  const [modalVisibleReson, setModalVisibleReson] = useState(false);
  const [fetchDetails, setFetchDetails] = useState([]);
  const snapPoints = useMemo(() => acceptOTP ? ["15%",  "65%"] :["15%",  "60%"]  , []);
  const Ridetails = useSelector(
    (state: RootState) => state?.rideDetailsSelector?.RideDetails
  );
  const bottomSheetModalRef = useRef(null);
  const bottomSheetModalRef1 = useRef(null);
  const bottomSheetModalRef2 = useRef(null);

  const [mapRegion, setMapRegion] = useState({
    latitude: loctionData?.coords?.latitude,
    longitude: loctionData?.coords?.longitude,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  });
  console.log("RidetailsRidetails-----", Ridetails)
  const markerRotation = useRef(new Animated.Value(0)).current;
  const handlePresentModalPress = useCallback(() => {
    bottomSheetModalRef.current?.present();
  }, []);
  const handleCancleFunction = useCallback(() => {
    bottomSheetModalRef1.current?.present();
  }, []);
  const RateModalFunctionOpen = useCallback(() => {
    setModalVisibleRate(true)
    bottomSheetModalRef2.current?.present();
  }, []);

  const handlePresentModalPressClose = useCallback(() => {
    bottomSheetModalRef.current?.close();
  }, []);

  const caoncleHandlerModal = useCallback(() => {
    bottomSheetModalRef1.current?.close();
  }, []);
  const handleSheetChanges = useCallback((index: number) => {
    console.log("handleSheetChanges", index);
  }, []);
  const handleSheetChanges1 = useCallback((index: number) => {
    console.log("handleSheetChanges", index);
  }, []);

  const closeTheModalCancelRider = () => {
    caoncleHandlerModal()
    handleCancleFunction()
  };

  console.log("=======>>>>>", currentLog)


  const closeDataChat = () => {
    navigation?.navigate("ChatDrivertoUser", { data: Ridetails });
  };

  useEffect(() => {
    console.log("asdasd-->555");
    handlePresentModalPress();
  }, [Isfocus]);


  const callEmergencyServices = () => {
    OSOHandlerAPI();

  };

  const OSOHandlerAPI = async () => {
    setLoader(true);
    axios({
      method: "POST",
      url: createSOS,
      headers: {
        token: token
      },
      data: {
        rideId: RideID,
        lastLat: loctionData?.coords?.latitude.toString(),
        lastLng: loctionData?.coords?.longitude.toString(),
      },
    })
      .then((response) => {
        console.log("SOS----hanlder", response?.data);
        if (response.data.responceCode === 200) {
          setLoader(false);
          showMessage({
            message: response?.data?.message,
            type: "success"
          })

        } else {
          console.log("first--------->")
        }
      })
      .catch((err) => {
        console.log(
          "=============errroroor=======================",
          err.response?.data
        );
        setLoader(false);
      });
  };

  

  const RateDriverForRide = async () => {
    setLoader(true);
    axios({
      method: "POST",
      url: rateDriver,
      data: {
        rideId: RideID,
        userId: Data?._id,
        riderRating: SelectStar,
        riderReview: "review"
      },
    })
      .then((response) => {
        if (response.data.responceCode === 200) {
          setModalVisibleRate(false);
          setLoader(false);
          showMessage({
            message: response?.data?.message,
            type: "success",
            icon: "success",
            duration: 2000,
          });
          setTimeout(() => {
            props?.navigation?.dispatch(
              CommonActions.reset({
                index: 0,
                routes: [{ name: "BottomTabBar" }],
              })
            );
          }, 500);

        } else {
          console.log("first--------->", error)
        }
      })
      .catch((err) => {
        console.log(
          "=============RATE=======================",
          err.response?.data
        );
        setLoader(false);
      });
  };
  const CancelRiderRequestHandler = async () => {
    setLoader(true);
    axios({
      method: "POST",
      url: cancelRide,
      data: {
        userId: Data?._id,
        rideId: RideID,
        reason: selectedReasonRide,
      },
    })
      .then((response) => {
        if (response.data.responceCode === 200) {
          setModalVisibleReson(false);
          setLoader(false);
          CancleRideSocket();
          showMessage({
            message: response?.data?.message,
            type: "success",
            icon: "success",
            duration: 1000,
          });
          setTimeout(() => {
            props?.navigation?.dispatch(
              CommonActions.reset({
                index: 0,
                routes: [{ name: "BottomTabBar" }],
              })
            );
          }, 500);
        } else {
        }
      })
      .catch((err) => {
        console.log(
          "=============errroroor=======================",
          err.response?.data
        );
        setLoader(false);
      });
  };

  const CancelReasonModal = () => {
    // handlePresentModalPressClose();
    setModalVisibleReson(true);
  };

  // Effect to update map region when marker position changes
  useEffect(() => {
    setMapRegion((prevRegion) => ({
      ...prevRegion,
      // latitude: currentLog.lat,
      // longitude: currentLog.lng,
      latitude: loctionData?.coords?.latitude,
      longitude: loctionData?.coords?.longitude,


    }));
  }, [currentLog]);


  useEffect(() => {
    const newSocket = io(SOCKET_URL, {
      transports: ["websocket"],
      reconnection: true, // Enable reconnection
      reconnectionAttempts: 5, // Number of reconnection attempts before giving up
      reconnectionDelay: 1000, // Initial delay before attempting to reconnect (in milliseconds)
      reconnectionDelayMax: 5000, // Maximum delay between reconnection attempts
      randomizationFactor: 0.5,
      auth:{
        _id:Data?._id
      }
    });

    newSocket.on("connect", () => {
      console.log("Socket connected");
    });

    console.log("Data?._idData?._idData?._idData?._id",Data?._id);


    newSocket.on("newRide", (response) => {
      console.log("kasdkajsdresponse=====88", response);
      if (response) {
        setFetchDetails(response?.nearbyDrivers);
        newSocket.on("rideDetails", (response) => {
          console.log("rideDetails---->>>R", response)
          if (response?.riderDetails?.riderId === Data?._id) {
            console.log("8888888888810===1-R",response?.riderDetails?.riderId);
            console.log("99999999910===-1-R",Data?._id);
            dispatch(setSaveRideData(response));
            setRideDetails(response);
            // CancelReasonModalRate();
            console.log("88988945441512-555", response);
          }
        });
        newSocket.on("driverLocationUpdated", (response) => {
          console.log("driverLocationUpdated-********-driverLocationUpdated", response);
          if (response) {
            // Modal open ride completed
            console.log("driverLocationUpdated-555", response);
          }
        });

        newSocket.on("rideEnded", (response) => {
          console.log("tttetetetetetetete3",response)
          // if (response) {
            if (response?.ridedata?.status === "completed" && response?.ridedata?.riderId?._id === Data?._id) {
            // Modal open ride completed
            RateModalFunctionOpen();
            console.log("rideEndedrideEnded-555", response);
          }
        });
      }
    });

    newSocket.on("disconnect", (reason) => {
      console.log("Socket disconnected:", reason);
    });

    return () => {
      newSocket.disconnect();
    };
  }, []);

  useEffect(() => {
    if (Ridetails) {
      setLoader(false);
    }
  }, [Ridetails]);

  //-----------------------Location Modal ------------------//
  async function requestPermissionLocation() {
    try {
      if (Platform.OS === "android") {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
          {
            title: "Allow Ponttual to use your location?",
            message:
              "Pontual App needs access to your device's location to provide accurate information.",
            buttonNeutral: "Ask Me Later",
            buttonNegative: "Cancel",
            buttonPositive: "OK",
          }
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          return true;
        } else {
          return false;
        }
      } else if (Platform.OS === "ios") {
        const result = await request(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE);
        // console.log("result----location", result);
        if (result === "granted") {
          return true;
        } else if (result === "blocked") {
          return false;
        } else {
          // ExitApp.exitApp();

          return false;
        }
      }
    } catch (err) {
      console.log(err);
      return false;
    }
  }

  const getLocation = async () => {
    const result = requestPermissionLocation();
    console.log('hdjshjdhsjhdsjhdsjhsdjh')
    result.then((res) => {
      // console.log("res is:-------1698", res);
      if (res) {
        Geolocation.getCurrentPosition(
          (position) => {
            // console.log("position-------", position);
            dispatch(setSavedCordinated(position))
            getLiveLocation(
              position?.coords?.latitude,
              position?.coords?.longitude
            );
          },
          (error) => {
            console.log("sdgdsfhdsh----198", error);
          },
          { enableHighAccuracy: false, timeout: 15000 }
        );
      } else {
        console.log("location permission decline");
      }
    });
    // console.log(location);
  };

  const getLiveLocation = async (latitude, longitude) => {
    const locPermissionDenied = await requestPermissionLocation();
    if (locPermissionDenied) {
      // console.log("get live location after 4 second", heading);
      animate(latitude, longitude);
      dispatch(setLocation({ latitude, longitude }));
    }
  };
  const animatedCoordinate = new AnimatedRegion({
    latitude: loctionData?.coords?.latitude,
    longitude: loctionData?.coords?.longitude,
  });
  const animate = (latitude, longitude) => {
    const newCoordinate = { latitude, longitude };
    if (Platform.OS == "android") {
      if (markerRef.current) {
        markerRef.current.animateMarkerToCoordinate(newCoordinate, 7000);
      }
    } else {
      // coordinate.timing(newCoordinate).start();
      animatedCoordinate.timing(newCoordinate).start();
    }
  };
  const [nearbyDrivers, setNearByDrivers] = useState([])

  useEffect(() => {
    AppState.addEventListener("change", (nextAppState) => {
    });
    const intervalId = BackgroundTimer.setInterval(() => {
      getLocation();
    }, 15000);
    return () => {
      clearInterval(intervalId);
    };
  }, [Isfocus]);

  useEffect(()=>{
    socketServcies?.on("rideStarted", (response) => {
      console.log("ride sarted=>>", response)
      console.log("Ridetails?.rideId-11", Ridetails?.rideId)
      if (response?.rideId === Ridetails?.rideId && response?.status === "rideStart") {
        setTimeout(() => {
          console.log("Ride Verified")
          setAcceptOTP(true)
          showMessage({
            message: "Your ride has been verified",
            type: "success",
            duration: 5000
          })
        }, 500)

      }
    })
  },[Isfocus])

  //SOCKET to verify ride
  const rideVerify = (Ridetails) => {
    socketServcies?.on("rideStarted", (response) => {
      console.log("ride sarted=>>", response)
      console.log("Ridetails?.rideId-11", Ridetails?.rideId)
      if (response?.rideId === Ridetails?.rideId && response?.status === "rideStart") {
        setTimeout(() => {
          console.log("Ride Verified")
          setAcceptOTP(true)
          showMessage({
            message: "Your ride has been verified",
            type: "success",
            duration: 5000
          })
        }, 500)

      }
    })
  }

  const CancleRideSocket = (RideId, Data) => {
    const rideId = Ridetails?.rideId;
    const userId = Data?._id;
    socketServcies.emit("rideCancled", { rideId: rideId, type: "rider" }, (res) => {
      console.log("rideCanceled response:", res);
    });
  };

  // const CancleRideSocketResponse = () => {
  //   socketServcies.on("yourRideCancled", (response) => {
  //    console.log("jjjjjjfjfjfjfjfjfjfjf",response)
  //    if (response?.riderId  === Data?._id) {
  //     showMessage({
  //      message: "Your ride is cancelled !!!!",
  //      type: "danger",
  //      duration: 5000
  //    })
  
  //    bottomSheetModalRef1?.current?.close()
  //    setTimeout(() => {
  //      props?.navigation?.dispatch(
  //        CommonActions.reset({
  //          index: 0,
  //          routes: [{ name: "BottomTabBar" }],
  //        })
  //      );
  //    }, 200);
  //    })
  //  }
  const CancleRideSocketResponse = () => {
    socketServcies.on("yourRideCancelled", (response) => {
      console.log("Ride cancellation response:", response);
      if (response?.riderId === Data?._id) {
        console.log("response?.riderId === Data?._id",response?.riderId === Data?._id);
        showMessage({
          message: "Your ride is cancelled!",
          type: "danger",
          duration: 5000,
        });
        bottomSheetModalRef?.current?.close();
        bottomSheetModalRef1?.current?.close();
        setTimeout(() => {
          props?.navigation?.dispatch(
            CommonActions.reset({
              index: 0,
              routes: [{ name: "BottomTabBar" }],
            })
          );
        }, 200);
      }
    });
  };

  const handleNearbyDrivers = () => {
    setTimeout(() => {
      NearbyDrivers();
    }, 10000)
  }

  //SOCKET for near by drivers
  const NearbyDrivers = () => {
    const lat = loctionData?.coords?.latitude;
    const lng = loctionData?.coords?.longitude;
    console.log("cureent latttt---", lat);
    console.log("current long", lng);
    socketServcies.emit("checkNearbyDriver", { lat, lng }, (response) => {
      console.log("socket emited for nearby Drivers", response)
    })
    socketServcies.on("nearbyDriver", (response) => {
      console.log("1----NearBy Drivers--->>", response)
      if (response) {
        setNearByDrivers(response)
      }
    })
  }


  useEffect(() => {
    rideVerify(Ridetails);
    handleNearbyDrivers();
    CancleRideSocketResponse();
  }, [Isfocus, Ridetails])

  return (
    <>
      <SafeAreaView style={{ flex: 1, backgroundColor: 'transparent' }}>
        <StatusBar backgroundColor={COLORS.WHITE} barStyle={"dark-content"} />

        <GestureHandlerRootView style={{ flex: 1, }}>
          <MapView
            ref={myRef}
            style={{
              position: "absolute",
              top: 0,
              right: 0,
              bottom: 0,
              left: 0,
              height: HEIGHT,
            }}
            region={mapRegion}
            zoomEnabled={true}
            scrollEnabled={true}
          >
            <MapViewDirections
              origin={{
                // latitude: currentLog.lat,
                // longitude: currentLog.lng,
                latitude: loctionData?.coords?.latitude,
                longitude: loctionData?.coords?.longitude,

              }}
              destination={{
                latitude: dropLatLog.lat,
                longitude: dropLatLog.lng,
                // latitude: 28.555410,
                // longitude: 77.290260,

              }}
              apikey="AIzaSyCzU4XQ6D43-mEnHWZ5l3vobePxE6p2GRw"
              strokeWidth={5}
              strokeColor="rgba(255, 85, 0, 1)"
            />
            <Marker.Animated
              ref={markerRef}
              coordinate={{
                latitude: loctionData?.coords?.latitude,
                longitude: loctionData?.coords?.longitude,
                // latitude: 28.632430,
                // longitude: 77.218790,
              }}
              anchor={{ x: 0.5, y: 0.5 }}

            >
              <Image
                source={require("../../assets/Images/track.png")}
                style={{ width: 35, height: 35 }}
              />
            </Marker.Animated>
            <Marker
              coordinate={{
                latitude: dropLatLog.lat,
                longitude: dropLatLog.lng,
              }}
              anchor={{ x: 0.5, y: 0.5 }}
            >
              <Image
                source={require("../../assets/Images/ic_Pin.png")}
                style={{ width: 35, height: 45 }}
              />
            </Marker>
            {nearbyDrivers.map(driver => (
              <Marker
                key={driver?.driverId}
                coordinate={{
                  latitude: driver.location.coordinates[0],
                  longitude: driver.location.coordinates[1]
                }} >
                <Image source={IMAGEPATH.newCar} style={{ width: 35, height: 35 }} />
              </Marker>)

            )}
          </MapView>
          <View style={styles.mainView}>
            <TouchableOpacity
              style={styles.backIcon}
              onPress={() => navigation.navigate("BottomTabBar")}
            >
              <VECTOR_ICONS.Ionicons
                name="chevron-back"
                size={26}
                color={""}
                style={{ alignSelf: "center" }}
              />
            </TouchableOpacity>

            <TouchableOpacity style={{ width: WIDTH * 0.94, paddingVertical: 20 }} onPress={callEmergencyServices}>
              <VECTOR_ICONS.MaterialIcons
                name="wifi-calling"
                size={26}
                color={"red"}
                style={{ position: "absolute", left: 0,bottom:0, }}

              />
              <Text style={{ position: "absolute", left: 30,bottom:0, color: 'red', fontWeight: '800', fontSize: 20 }}>
                SOS
              </Text>
            </TouchableOpacity>

            <BottomSheetModalProvider>

              <View style={styles.container}>
                <BottomSheetModal
                  ref={bottomSheetModalRef2}
                  index={1}
                  handleIndicatorStyle={{
                    backgroundColor: "transparent"
                  }}
                  backgroundStyle={{
                    backgroundColor: "transparent"
                  }}
                  snapPoints={snapPoints}
                  onChange={handleSheetChanges}
                >
                  <View style={styles.contentContainer}>
                    <RateModalComponent
                      setModalVisible={setModalVisibleRate}
                      modalVisible={modalVisibleRate}
                      rate={"Rate Your Driver"}
                      head={"Ride Finished"}
                      Message={"Cash Paid - $24.89"}
                      img
                      Button="Submit"
                      source={IMAGEPATH.success}
                      imgstyle={{ width: 48, height: 48, resizeMode: "cover" }}
                      modalstyle={{ width: WIDTH * 0.75 }}
                      msgstyle={{ fontSize: 16, color: "#242E42" }}
                    />
                  </View>
                </BottomSheetModal>
              </View>
            </BottomSheetModalProvider>
          </View>
          <BottomSheetModalProvider>
            <View style={styles.container}>
              <BottomSheetModal
                ref={bottomSheetModalRef}
                index={1}
                snapPoints={snapPoints}
                enableOverDrag={false}
                enablePanDownToClose={false}
                handleIndicatorStyle={{
                  backgroundColor: "rgba(155, 155, 155, 1)",
                  width: 70,
                  height: 6
                }}
                onChange={handleSheetChanges}
              >
                <View style={styles.contentContainer}>
                  <BookConfirmpopup
                    Action1={() => closeTheModalCancelRider()}
                    Action2={() => {
                      RateModalFunctionOpen();
                    }}
                    acceptOTP={acceptOTP}
                    Ridetails={Ridetails}
                    Action={() => {
                      closeDataChat();
                    }}
                  />
                </View>
              </BottomSheetModal>
            </View>
          </BottomSheetModalProvider>
          <BottomSheetModalProvider>
            <View style={styles.container}>
              <BottomSheetModal
                ref={bottomSheetModalRef1}
                index={1}
                snapPoints={snapPoints}
                onChange={handleSheetChanges1}
              >
                <View style={styles.contentContainer}>
                  <CancelYourRide
                    setReasonRide={setReasonRide}
                    selectedReasonRide={selectedReasonRide}
                    Action1={() => {
                      handlePresentModalPressClose()
                      bottomSheetModalRef1?.current?.close()
                      setTimeout(() => {
                        props?.navigation?.dispatch(
                          CommonActions.reset({
                            index: 0,
                            routes: [{ name: "BottomTabBar" }],
                          })
                        );
                      }, 200);
                    }

                    }
                    Action={() => {
                      CancelReasonModal();
                    }}
                  />
                </View>
              </BottomSheetModal>
            </View>
          </BottomSheetModalProvider>
          <ModalComponent
            setModalVisible={setModalVisibleReson}
            modalVisible={modalVisibleReson}
            Message={"Are you sure, you want to cancel your"}
            Message1={"ride?"}
            head={"Cancel Your Ride"}
            Button12
            btn1={"Back"}
            btn2={"Confirm"}

            // navigated={()=>{setModalVisible(false);}}
            navigated={() => {
              setModalVisibleReson(false),
                setTimeout(() => {
                  props?.navigation?.dispatch(
                    CommonActions.reset({
                      index: 0,
                      routes: [{ name: "BottomTabBar" }],
                    })
                  );
                }, 500);
            }}
            Action={() => {
              CancelRiderRequestHandler();
            }}
            source={IMAGEPATH.cancle}
            imgstyle={{}}
            modalstyle={
              {
                // height:platformType==='ios'? 284:  HEIGHT*0.38,
              }
            }
          />
        </GestureHandlerRootView>
      </SafeAreaView>
      <SafeAreaView style={{ backgroundColor: "#fff" }}></SafeAreaView>
    </>
  );
};

export default YourComponent;

const styles = StyleSheet.create({
  mainView: { width: WIDTH * 0.9, alignSelf: "center", position: "relative" },
  backIcon: {
    backgroundColor: "rgba(0, 0, 0, 0.1)",
    width: 46,
    height: 46,
    borderRadius: 23,
    marginVertical: "5%",
    alignItems: "center",
    justifyContent: "center",
  },
  handmainview: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },

  lineStyle: {
    borderBottomColor: "rgba(239, 239, 244, 1)",
    borderBottomWidth: 2,
    width: WIDTH,
    alignSelf: "center",
    marginVertical: "2%",
  },
  dotsstyle: { alignItems: "center", justifyContent: "center" },

  firstView1: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    backgroundColor: COLORS.WHITE,
  },
  locationview: {
    flexDirection: "row",
    // marginVertical: HEIGHT * 0.01,
    width: WIDTH * 1,
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "space-between",
  },
  backbtn: {
    marginVertical: "1%",
    width: WIDTH * 0.9,
  },
  mobiloitte: {
    fontFamily: FONTS.medium,
    fontSize: 15,
    color: "#C8C7CC",
  },
  canceltext: {
    fontFamily: FONTS.bold,
    fontSize: 17,
    color: "rgba(36, 46, 66, 1)",
  },
});

