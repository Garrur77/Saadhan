
export const IMAGEPATH = {
  // ------------------ splash ------------------

  // GlobalBackGroundImg:require("../Images/GlobalBackImg/globalbackgroundImg.png"),
  GlobalBackGroundImg: require("../Images/GlobalBackImg/backgroundimg.png"),
  GlobalBackGroundImg1: require("../Images/GlobalBackImg/createAccount.png"),
  Splash: require("../Images/Splash/Splash.png"),
  IntroVidio: require("../Images/Splash/Introvidio.png"),
  Setuponmap: require('../Images/BookRide/Setuponmap.png'),
  Map: require("../Images/Splash/map.png"),
  Plogo: require("../Images/Splash/Plogo.png"),
  LogoMain: require("../Images/Splash/Logo.png"),
  LocationBackground: require("../Images/GlobalBackImg/Locationpermission.png"),
  // Splash: require('../Images/Splash/Splash.png'),


  // ------------------ Notification ------------------
  Bell: require('../Images/NOtification/Notification.png'),
  bellimg: require("../Images/NOtification/bellimg.png"),
  delete: require('../Images/NOtification/delete.png'),
  line: require("../Images/NOtification/Line 43.png"),
  circle: require('../Images/NOtification/Circle.png'),
  logo: require('../Images/NOtification/logo.png'),
  searchmap: require('../Images/NOtification/SearchMap.png'),
  location: require('../Images/NOtification/location.png'),
  clock: require('../Images/NOtification/Clock.png'),
  shape: require('../Images/NOtification/Shape.png'),
  dropoff: require('../Images/NOtification/Dropoff.png'),
  Phone: require('../Images/BookRide/Phone.png'),

  // ---------------------- Map --------------------------
  MapBackground: require("../Images/GlobalBackImg/mapbackgroundimg.png"),
  SelectedCircle: require("../Images/BookRide/selected.png"),
  NotSelectedCircle: require("../Images/BookRide/notselected.png"),
  call: require('../Images/BookRide/Call.png'),
  Man: require('../Images/BookRide/Man.png'),
  Man2: require('../Images/BookRide/Man2.jpg'),
  star: require('../Images/BookRide/Star.png'),
  car: require('../Images/BookRide/Car1.png'),
  chat: require('../Images/BookRide/chat.png'),
  newCar: require('../Images/newCar.png'),

  // ---------------------- Modalimg --------------------------
  success: require('../Images/Modalimg/Success.png'),
  cancle: require('../Images/Modalimg/Cancle.png'),
  // ------------------------ History -------------------------
  // Car :require("../Images/BookRide/car.png"),
  GroupLocation: require('../Images/History/groupLocation.png'),
  Car: require("../Images/BookRide/ReciptCar.png"),
  history: require("../../assets/Icons/history.png"),
  account: require("../../assets/Icons/account.png"),
  home: require("../../assets/Icons/home.png"),
  // -------------------------Account --------------------------
  ProfilePic: require("../Images/Account/ProfilePic.png"),
  dummyProfile: require("../Images/Account/DummyProfile.jpeg"),
  // Car :require("../Images/BookRide/car.png"),
  Home: require("../Images/BookRide/homep.png"),
  Logout: require("../Images/Account/Logout.png"),
  Wallet: require('../Images/Account/Wallet.png'),
  History: require("../Images/Account/history.png")
} 
