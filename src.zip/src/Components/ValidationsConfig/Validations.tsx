import { ErrorMessages } from './ErrorMessage';

/************************************ Regex **************************************************/
export const EMAILREGEX =
  /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]{5,255}@[a-zA-Z0-9-]{2,63}\.[a-zA-Z]{2,63}$/;
export const PASSWORDREGEX =
  /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
export const DIGITREGEX =
  /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-.]).{8,}$/;
export const ALPHANUMERIC_REGEX = /^[a-zA-Z0-9]*$/;
export const FULLNAME_REGEX = /^([a-zA-Z]+\s?){1,2}[a-zA-Z]+$/;
export const FIRSTNAME_REGEX = /^[a-zA-Z]+$/;
export const LASTREGEX_REGEX = /^[a-zA-Z]+(?: [a-zA-Z]+){1,2}$/;
// export const FIRSTNAME_REGEX = /^[a-zA-Z]+(?: [a-zA-Z]+)?$/;

export let DECIMAL_REGEX = /^\d*\.?\d*$/;
export let NUMBER_REGEX = /^\d*$/;
export let ALPHABET_SPACE_REGEX = /^[a-zA-Z ]*$/;
export let WEBSITE_REGEX =
  /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
export let USERNAME_REGEX = /^[a-z0-9_]*$/;
export let USER_REGEX = /^(?=[a-zA-Z0-9._]{8,20}$)(?!.*[_.]{2})[^_.].*[^_.]$/;
export let alphabetic = /[a-zA-Z]/g;
// export let PhoneRegex = /^(\([0-9]{3}\) |[0-9]{3}-)[0-9]{3}-[0-9]{4}/;
export let PhoneRegex = /^([0-9]){7,13}$/;


// Phone number regex for India (10 digits)
const indiaPhoneNumberRegex = /^(\+91-|\+91|0)?[6789]\d{9}$/;

// Phone number regex for International (Assuming any country code and 10 digits)
const internationalPhoneNumberRegex = /^\+\d{1,4}\d{10}$/;



/************************************ All Validations **************************************************/
/***** EMAIL VALIDATION ****/

export const ValidateEmail = (email: string) => {
  if (email != '') {
    if (EMAILREGEX.test(email)) {
      return '';
    } else {
      return ErrorMessages.EmailError;
    }
  } else {
    return ErrorMessages.EmailEmpty;
  }
};
/***** PASSWORD VALIDATION ****/
export const ValidatePassword = (password: any) => {
  if (password != '') {
    if (PASSWORDREGEX.test(password)) {
      return '';
    } else {
      return ErrorMessages.PasswordError;
    }
  } else {
    return ErrorMessages.PasswordEmpty;
  }
};

export const ValidatePasswordlogin = (password: any) => {
  if (password != '') {
    if (PASSWORDREGEX.test(password)) {
      return '';
    } else {
      return ErrorMessages.WrongPassword;
    }
  } else {
    return ErrorMessages.PasswordEmpty;
  }
};
/***** FORGOT PASSWORD VALID ****/
// export const CodeVerification = Code => {
//   if (Code != '') {
//     if (Code == '0000') {
//       return '';
//     } else {
//       return ErrorMessages.CodeError;
//     }
//   } else {
//     return ErrorMessages.CodeEmpty;
//   }
// };
/***** Validation ChangePassword ****/
export const ValidateChangePassword = (changepassword_: any) => {
  if (changepassword_ != '') {
    if (changepassword_.length < 8) {
      return ErrorMessages.ChangePasswordbelow8;
    } else {
      if (PASSWORDREGEX.test(changepassword_)) {
        return '';
      } else {
        return ErrorMessages.PasswordError;
      }
    }
  } else {
    return ErrorMessages.ChangepasswordEmpty;
  }
};

/***** Validation ConfirmPassword ****/
export const ValidateConfirmPassword = (
  ConfirmPassword: any,
  Password: any,
) => {
  if (ConfirmPassword != '') {
    if (ConfirmPassword == Password) {
      return '';
    } else {
      return ErrorMessages.ConfirmPasswordMatch;
    }
  } else {
    return ErrorMessages.ConfirmPasswordEmpty;
  }
};

/***** Validation Fullname ****/
export const ValidateFirstname = (fname: string) => {
  if (fname !== '') {
    if (FIRSTNAME_REGEX.test(fname)) {
      return '';
    } else {

      return ErrorMessages.ValidFirstName;

    }
  } else {
    return ErrorMessages.FirstNameEmpty;
  }
};
/***** Validation Last_name ****/
export const ValidateLastname = (lname: string) => {
  if (lname !== '') {
    if (LASTREGEX_REGEX.test(lname)) {
      return '';
    } else {
      return ErrorMessages.LastNameError;
    }
  } else {
    return ErrorMessages.LastNameEmpty;
  }
};

export const OTPVerification = (Code: number) => {
  const codeStr = Code.toString();
  if (codeStr != '') {
    if (codeStr.length != 6) {
      return ErrorMessages.CodeLengthError;
    } else {
      return '';
    }
  } else {
    return ErrorMessages.CodeEmpty;
  }
};


export const ValidateMobileNo = (code: string, MobileNumber: string) => {
  console.log("data---->MobileNumber", MobileNumber);
  if (MobileNumber !== "") {
    const NumberStr = MobileNumber // Convert to string

    if (code === "+91") {
      if (indiaPhoneNumberRegex.test(MobileNumber)) {
        return "";
      } else {
        return ErrorMessages.PhoneNumberError;
      }
    } else {
      if (internationalPhoneNumberRegex.test(MobileNumber)) {
        return "";
      } else {
        return ErrorMessages.PhoneNumberError;
      }
    }
  } else {
    return ErrorMessages.PhoneNoEmpty;
  }
};

export const ValidateMobileNumber = (phone: string) => {
  const numericPhone = phone.replace(/[^0-9]/g, ''); // Remove non-numeric characters
  const phoneLength = numericPhone.length;

  if (phoneLength < 8 || phoneLength > 16) {
    return "Phone number must be between 8 and 16 digits.";
  }

  return ""; // No error
};

// export const ValidateMobileNo = (MobileNumber : number) => {

//     const NumberStr = MobileNumber.toString();

//   if (NumberStr != '') {
//     if (PhoneRegex.test(NumberStr)) {
//       return '';
//     }
//     else {
//       return ErrorMessages.PhoneNumberError
//     }
//   } else {
//     return ErrorMessages.PhoneNoEmpty
//   }
// }
// export const ValidateFullname = (fullname: string) => {
//   if (fullname !== '') {
//     if (fullname?.length >= 2 && FULLNAME_REGEX.test(fullname)) {
//       return '';
//     } else {
//       if (fullname.length < 2) {
//         return ErrorMessages.FullnameError;
//       } else {
//         return ErrorMessages.FullnameError;
//       }
//     }
//   } else {
//     return ErrorMessages.FullnameEmpty;
//   }
// };

export const ValidateFullname = (name: string) => {
  const trimmedName = name.trim(); // Remove leading and trailing spaces

  if (!trimmedName) {
    return "Name is required.";
  }

  // Check if the name contains numbers or special characters
  if (/[^a-zA-Z ]/.test(trimmedName)) {
    return "Name should only contain letters and spaces.";
  }

  return ""; // No error
};


// export const ValidateMobileNo = (MobileNumber: string) => {
//   if (MobileNumber !== '') {
//     const NumberStr = MobileNumber.toString(); // Convert to string

//     if (PhoneRegex.test(NumberStr)) {
//       return '';
//     } else {
//       return ErrorMessages.PhoneNumberError;
//     }
//   } else {
//     return ErrorMessages.PhoneNoEmpty;
//   }
// };

export const ValidateCityField = (city: string) => {
  if (city !== undefined && city.length >= 3 && city.length <= 50) {
    return '';
  } else {
    return ErrorMessages.CityLengthInvalid;
  }
};

export const ValidateAddCategory = (Category: string) => {
  if (Category != '' && Category != null && Category != undefined) {
    return '';
  } else {
    return 'Please Add Your Category';
  }
};

export const ValidationMessgaeBox = (message: string) => {
  if (message === '' || message === null || message === undefined) {

    return ErrorMessages.EmptyMessage;
  } else if (message.length < 5) {

    return ErrorMessages.MessgaeLength;
  } else {

    return '';
  }


}

