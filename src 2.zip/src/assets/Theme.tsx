import { COLORS } from "../assets/Colors/Color";
import { IMAGEPATH } from "../assets/Images/Images";
import { FONTS } from "../assets/Fonts/Index";
import { VECTOR_ICONS } from "../assets/Icons/Icons";


export { COLORS, IMAGEPATH , FONTS, VECTOR_ICONS}