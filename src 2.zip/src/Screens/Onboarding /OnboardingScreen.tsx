import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  Platform,
  StatusBar,
} from "react-native";
import React, { useState, useEffect } from "react";
import OnBoarding1 from "../../Components/SvgComponent/OnBoarding1";
import OnBoarding2 from "../../Components/SvgComponent/OnBoarding2";
import OnBoarding3 from "../../Components/SvgComponent/OnBoarding3";
import { WIDTH, HEIGHT } from "../../Components/Helpers/Dimentions";
import { COLORS, FONTS } from "../../assets/Theme";
import { SwiperFlatList } from "react-native-swiper-flatlist";
import DeviceNumber from "react-native-device-number";
import { CommonActions } from "@react-navigation/native";
const platformType = Platform.OS;
const OnboardingScreen = (props: any) => {
  const [currentIndex, setCurrentIndex] = useState(true);

  useEffect(() => {
    console.log(currentIndex, "currentIndex");
  }, [currentIndex]);

  const data = [
    {
      key: 1,
      image: "OnBoarding1",
      text: "Request Ride",
      text1: "Request a ride get picked up by a nearby \ncommunity driver",
    },
    {
      key: 2,
      image: "OnBoarding2",
      text: "Confirm Your Driver",
      text1:
        "Huge drivers network helps you find \ncomforable, safe and cheap ride",
    },
    {
      key: 3,
      image: "OnBoarding3",
      text: "Track your ride",
      text1:
        "Know your driver in advance and be able to \nview current location in real time on the map ",
    },
  ];

  function renderTutorialComponent(imageName) {
    switch (imageName) {
      case "OnBoarding1":
        return <OnBoarding1 style={styles.imageStyle} />;
      case "OnBoarding2":
        return <OnBoarding2 style={styles.imageStyle} />;
      case "OnBoarding3":
        return <OnBoarding3 style={styles.imageStyle2} />;
      default:
        return null;
    }
  }

  const getStartedHandler = () => {
    // props?.navigation?.dispatch({
    props?.navigation?.dispatch(
      CommonActions.reset({
        index: 0,
        routes: [{ name: "Introduction" }],
      })
    );
    // })
    // props.navigation.navigate('Introduction')
  };
  return (
    <>
      <SafeAreaView style={{ backgroundColor: COLORS.WHITE }}></SafeAreaView>
      <StatusBar backgroundColor={COLORS.WHITE} barStyle={"dark-content"} />
      <SafeAreaView style={{ flex: 1, backgroundColor: "white" }}>
        <SwiperFlatList
          paginationStyleItem={{ height: 6, width: 22 }}
          paginationActiveColor="rgba(255, 85, 0, 1)"
          paginationStyleItemActive={{ height: 6, width: 26 }}
          paginationDefaultColor="rgba(239, 239, 244, 1)"
          autoplayLoop
          data={data}
          showPagination
          paginationStyle={{
            gap: -18.6,
            marginBottom: "3%",
            position: "absolute",
          }}
          renderItem={({ item, index }) => (
            <View style={styles.Viewstyle}>
              {renderTutorialComponent(item.image)}

              <View style={{ marginTop: "15%" }}>
                <Text style={styles.Textstyle}>{item.text}</Text>
                <Text style={styles.hederText}>{item.text1}</Text>
              </View>
              {index == 2 && (
                <TouchableOpacity
                  style={styles.button}
                  onPress={getStartedHandler}
                >
                  <Text style={styles.Textstyle1}>GET STARTED!</Text>
                </TouchableOpacity>
              )}
            </View>
          )}
        />
      </SafeAreaView>
      <SafeAreaView style={{ backgroundColor: "#fff" }}></SafeAreaView>
    </>
  );
};

export default OnboardingScreen;

const styles = StyleSheet.create({
  Textstyle1: {
    fontFamily: FONTS.bold,
    fontSize: 16,
    fontWeight:"600",
    color: COLORS.WHITE,
  },
  Viewstyle: {
    width: WIDTH,
    alignItems: "center",
    justifyContent: "center",
    // marginBottom:'6%',
  },
  hederText: {
    marginVertical: "6%",
    alignSelf: "center",
    fontFamily: FONTS.medium,
    fontSize: 14,
    color: COLORS.GRAY,
    textAlign: "center",

  },
  button: {
    marginTop: platformType == "ios" ? "10%" : "8%",
    width: platformType === "ios" ? WIDTH * 0.48 : WIDTH * 0.45,
    borderRadius: 7,
    padding: "3%",
    alignItems: "center",
    backgroundColor: COLORS.BACKGROUNDBTNCOLOR,
  },
  Textstyle: {
    color: COLORS.BOARDBLACK,
    fontSize: 30,
    fontFamily: FONTS.bold,
    textAlign: "center",
    fontWeight: Platform.OS === 'ios' ? '600' : '400'
  },
  imageStyle: {
    alignSelf: "center",

  },
  imageStyle2: {
    alignSelf: "center",
    marginTop: Platform.OS === 'ios' ? "15%" : "0%"
  }
});
