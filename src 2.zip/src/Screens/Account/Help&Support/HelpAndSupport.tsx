import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions,
  TextInput,
  ScrollView,
  SafeAreaView,
  Platform,
  StatusBar,
} from 'react-native';
import Header from '../../../Components/HeaderComponent/Header';
import { HEIGHT } from '../../../Components/Helpers/Dimentions';
import { COLORS } from '../../../assets/Theme';
import axios from 'axios';
import { fetchhelpSupport } from '../../../ApiConfig/Endpoints';
import { useIsFocused } from '@react-navigation/native';
import WholeButton from '../../../Components/Wholebutton/Wholebutton';
import { callGetApi } from '../../../ApiConfig/ApiCall';


const { height, width, fontScale } = Dimensions.get('screen');

export default function Faqs(props) {
  const [showText, setShowText] = useState([
    false,
    false,
    false,
    false,
    false,
    false,
  ]);
  const isFoucs = useIsFocused()
  const [Loader, setLoader] = useState(false);
  const [datafaqs, setdasetFasDatatas] = useState('');
  const [faqs, setFasData] = useState([
    {
      id: 1,
      subject: 'How can I complete my KYC?',
      description:
        'Lorem ipsum is a placeholder text commonly used to demonstrate the visual form Lorem ipsum is a placeholder text commonly used to demonstrate the visual form',
    },
    {
      id: 2,
      subject: 'How can I complete my KYC?',
      description:
        'Lorem ipsum is a placeholder text commonly used to demonstrate the visual form Lorem ipsum is a placeholder text commonly used to demonstrate the visual form',
    },
    {
      id: 3,
      subject: 'How can I complete my KYC?',
      description:
        'Lorem ipsum is a placeholder text commonly used to demonstrate the visual form Lorem ipsum is a placeholder text commonly used to demonstrate the visual form',
    },
    {
      id: 4,
      subject: 'How can I complete my KYC?',
      description:
        'Lorem ipsum is a placeholder text commonly used to demonstrate the visual form Lorem ipsum is a placeholder text commonly used to demonstrate the visual form',
    },
    {
      id: 5,
      subject: 'How can I complete my KYC?',
      description:
        'Lorem ipsum is a placeholder text commonly used to demonstrate the visual form Lorem ipsum is a placeholder text commonly used to demonstrate the visual form',
    },
  ]);

  const helpNsupport = async () => {
    try {
      setLoader(true);
      const res = await axios({
        method: "get",
        url: fetchhelpSupport,

      })
      console.log("faq----->>", res?.data?.result)
      if (res?.data?.responseCode == 200) {

        console.log("result--->", res?.data?.result);
        setdasetFasDatatas(res?.data?.result)
        setLoader(false);
      }


    } catch (error) {
      console.log("error---->", error);
      setLoader(false);
    }
  };

  useEffect(() => {
    helpNsupport()
  }, [isFoucs])


  const toggleText = (index) => {
    const updatedState = [...showText];
    updatedState[index] = !updatedState[index];
    setShowText(updatedState);
  };

  return (
    <>
      <SafeAreaView
        style={{ backgroundColor: COLORS.BACKGROUNDBTNCOLOR }}
      ></SafeAreaView>
      <StatusBar
        backgroundColor={COLORS.BACKGROUNDBTNCOLOR}
        barStyle={"dark-content"}
      />
      <SafeAreaView style={{ flex: 1, }}>
        <View style={styles.container}>
          <Header navigation={props?.navigation} Heading={'Help & Support'}
            HeaderStyle={{ marginLeft: '15%' }} />
          <ScrollView
            showsVerticalScrollIndicator={false}
            style={styles.cardContainer}>
            {(datafaqs && datafaqs?.length === 0) || datafaqs?.length === undefined ? (
              <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', height: HEIGHT * 0.3 }}>

                <Text style={styles.noDataText}>No Faqs found</Text>
              </View>
            ) : (
              <>
                <View style={{ flex: 1, }}>

                  {datafaqs &&
                    datafaqs?.map((item, index) => (
                      <TouchableOpacity
                        activeOpacity={1}
                        onPress={() => toggleText(index)}
                        key={index}
                        style={styles.card}>
                        <View style={styles.cardHeader}>
                          <Text style={styles.question}>{item?.question}</Text>
                          <TouchableOpacity
                            activeOpacity={1}
                            onPress={() => toggleText(index)}>
                            <Image
                              source={
                                showText[index] ? require("../../../assets/Images/Account/chevron.leftTop.png") : require("../../../assets/Images/Account/chevron.left.png")
                              }
                              style={styles.icon}
                              resizeMode="contain"
                            />
                          </TouchableOpacity>
                        </View>
                        {showText[index] && (
                          <View
                            style={{
                              backgroundColor: 'rgba(255, 255, 255, 1)',
                              paddingVertical: 6,
                              // marginVertical: 10,
                            }}>
                            <Text style={{ color: "rgba(130, 132, 137, 1)", fontSize: 14, lineHeight: 20 }}>
                              {item?.answer}
                            </Text>

                          </View>
                        )}
                      </TouchableOpacity>
                    ))}
                </View>
              </>
            )}
          </ScrollView>
          <View style={styles.bottomButtonContainer}>
            {(datafaqs && datafaqs?.length > 0) ? (
              <WholeButton
                styles={{ backgroundColor: COLORS.BACKGROUNDBTNCOLOR, color: COLORS.WHITE }}
                Label={'SUBMIT YOUR QUERY'}
                Action={() => { props.navigation.navigate('SubmitYourQuery') }}
              />
            ) : null}
          </View>

        </View>
      </SafeAreaView>

    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
  },
  bottomButtonContainer: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    left: 0,
    paddingVertical: 15,
  },
  cardContainer: {
    gap: 12,
    marginTop: 25,
    position: 'relative'
    // backgroundColor:'#fff'
  },
  card: {
    paddingHorizontal: 10,
    paddingVertical: 10,
    marginBottom: 10,
    borderRadius: 8,
    backgroundColor: "#fff",
  },
  input: {
    flex: 1,
    height: height * 0.0655,
  },
  noDataText: {
    alignSelf: 'center',
    marginTop: 20,
    fontSize: 16,
    color: '#000',
  },
  icon: {
    // height: moderateScaleVertical(8),
    // width: moderateScale(14),
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  question: {
    paddingVertical: 5,
    color: "rgba(36, 46, 66, 1)",
    fontSize: 17,
    // fontFamily: FONT.Poppins500,
    marginBottom: 5,
  },
});
